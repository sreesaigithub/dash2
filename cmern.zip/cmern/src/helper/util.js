import requests from './requests';
import axios from 'axios';
import { Dialog, DialogContent, DialogContentText } from '@mui/material';
import { Spinner, Row, Col } from 'react-bootstrap';
import AlertErrorView from '../components/Dashboard/impactTracking/pages/widget/AlertErrorView';

const baseURL = window.__RUNTIME_CONFIG__.REACT_APP_ITD_BASE_API_URL;
// const oidcStorage = JSON.parse(
//   sessionStorage.getItem(
//     `oidc.user:${window.__RUNTIME_CONFIG__.REACT_APP_AUTH_URL}:${window.__RUNTIME_CONFIG__.REACT_APP_IDENTITY_CLIENT_ID}`
//   )
// );
let config = {
  headers:{
    // 'X-Api-Key': 'test_auth_sample',
    // "X-Amz-Security-Token": 'Test security Token',
    // "Authorization": 'Test_Auth',
  },
};
// if(oidcStorage) {
//   const { profile: { GroupNames = [], sub = ''} } = oidcStorage;
//   config = {
//     headers: {
//       'user_id': sub, 
//       'user_groups': Array.isArray(GroupNames) ? GroupNames.join(',') : GroupNames, 
//       'X-Api-Key': window.__RUNTIME_CONFIG__.REACT_APP_ITD_X_API_KEY ? window.__RUNTIME_CONFIG__.REACT_APP_ITD_X_API_KEY : '', 
//     },
//   };
// }

export function DoPostCall(serviceName, params = '', callBack, updateURL = '') {
  let url = `${baseURL}${requests[serviceName]}`;
  if (updateURL !== '') {
    url = url.replace(updateURL.find, updateURL.replace);
  }
  let response = '', errorMsg = '';
  axios.post(url, params, config)
    .then((response) => {
      response = response.data;
      callBack(true, response, errorMsg);
    })
    .catch((error) => {
      errorMsg = error.response.data.errors.message;
      errorMsg = errorMsg ? errorMsg : 'An Exception has occurred';
      callBack(false, response, errorMsg);
    })
    .finally(()=> {
      callBack(false, response, errorMsg);
   });
}

export function DoGetCall(serviceName = '', params, updateURL = '', callBack) {
  let url = `${baseURL}${requests[serviceName]}`;
  if (updateURL !== '') {
    url = url.replace(updateURL.find, updateURL.replace);
  }
  let response = '', errorMsg = '';
  const getParams = Object.assign(config, { params });
  axios.get(url, getParams)
    .then((response) => {
      response = response.data;
      callBack(true, response, errorMsg);
    })
    .catch((error) => {
      errorMsg = error.response.data.errors.message;
      errorMsg = errorMsg ? errorMsg : 'An Exception has occurred';
      callBack(false, response, errorMsg);
    })
    .finally(()=> {
      callBack(false, response, errorMsg);
   });
}

export function multiGetRequest(urls = [], params = [], callBack) {
  const reqURL = urls.map((serviceName) => `${baseURL}${requests[serviceName]}`);
  const getReq = reqURL.map((url, index) => {
    const getParams = Object.assign(config, { params: params[index] });
    return axios.get(url, getParams);
  });
  axios.all(getReq)
    .then(axios.spread((...responses) => {
      callBack(true, responses, []);
    }))
    .catch(errors => {
      callBack(false, [], errors);
    })
}

export function parseJobsDate(date = '') {
  if (date === '') {
    return '';
  }
  const first2Str = String(date).slice(0, 2);
  const first2Num = Number(first2Str);
  let month = -1, year = -1;
  if (first2Num > 12) {
    year = Number(String(date).slice(0, 4));
    month = Number(String(date).slice(4)) - 1;
  } else {
    month = Number(String(date).slice(0, 2)) - 1;
    year = Number(String(date).slice(2));
  }
  const dateObj = new Date(year, month, 1);
  const monthName = dateObj.toLocaleString('default', { month: 'short' });
  return `${monthName} ${year}`;
}

const downloadFile = ({ data, fileName, fileType }) => {
  const blob = new Blob([data], { type: fileType });
  const a = document.createElement('a');
  a.download = fileName;
  a.href = window.URL.createObjectURL(blob);
  const clickEvt = new MouseEvent('click', {
    view: window,
    bubbles: true,
    cancelable: true,
  });
  a.dispatchEvent(clickEvt);
  a.remove();
}

export function exportAsCSV(fileName, jsonData) {
  let { columns, data } = jsonData;
  columns = columns.map((col) => col.includes(',') ? `"${col}"` : col);
  const jsonToCSV = [];
  jsonToCSV.push(columns.join(','));
  data.forEach((row) => {
    jsonToCSV.push(row.join(','));
  });

  downloadFile({
    data: jsonToCSV.join('\n'),
    fileName: fileName,
    fileType: 'text/csv',
  });
}

export function showLoadingView(showDialog = false) {
  return (<Dialog
    open={showDialog}
    PaperProps={{
      style: {
        backgroundColor: 'transparent',
        boxShadow: 'none',
        color: 'white',
      },
    }}
  >
    <DialogContent>
      <DialogContentText>
        <Row>
          <Col><Spinner animation="border" variant="light" /></Col>
          <Col className="loadingStyle">Loading...</Col>
        </Row>
      </DialogContentText>
    </DialogContent>
  </Dialog>);
}

export function showErrorView() {
  return (
    <AlertErrorView />
  );
}

export function convertPercent (value = '') {
  if (!value) {
      return value === 0 ? '0%' : '';
  }
  let temp = new Intl.NumberFormat('us-IN', {
      style: 'percent',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
  }).format(value);

  return temp;
}

export function formatSignNumber (value = '', maximumFractionDigits = 2) {
  if (!value) {
      return value === 0 ? '$0' : '';
  }
  let cntValue = '';
  if (value < 0) {
      value = value * -1;
      value = value.toLocaleString('en-US', { maximumFractionDigits });
      cntValue = `-$${value}`;
  } else {
      value = value.toLocaleString('en-US', { maximumFractionDigits });
      cntValue = `$${value}`;
  }
  return cntValue;
}