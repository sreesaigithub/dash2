const requests ={
    fetchDevaUsers:'/api/DevaUser',
    fetchGroupName: '/register/Terms',
    fetchImpactDashBoardJobs: '/v1/jobs',
    fetchImpactDashBoardEvents: '/v1/events',
    fetchStage1WeightData: '/v1/jobs/<JOB_ID>/stage1/weight-data',
    fetchBalanceMetricsData: '/v1/jobs/<JOB_ID>/stage1/balance-metrics',
    fetchParallelAdjustedData: '/v1/jobs/<JOB_ID>/stage1/parallel-trend-metrics?type=adjusted',
    fetchParallelUnAdjustedData: '/v1/jobs/<JOB_ID>/stage1/parallel-trend-metrics?type=unadjusted',
    fetchParallelMetricData: '/v1/jobs/<JOB_ID>/stage1/parallel-trend-metrics?type=metrics',
    fetchValuesFilterData: '/v1/mbr-data/filter-fields-kpi',
    fetchSMDSummaryData: '/v1/jobs/<JOB_ID>/stage1/smd-summary',
    impactDashboardStage2Data:'/v1/jobs/<JOB_ID>/stage2',
    fetchOutcomesTableData: '/v1/jobs/<JOB_ID>/stage2/outcome-table',
    fetchMatrixSummaryData: '/v1/jobs/<JOB_ID>/stage2/metric-summary',
    fetchCostCurveData: '/v1/jobs/<JOB_ID>/stage2/cost-curve-metrics'
}

export default requests