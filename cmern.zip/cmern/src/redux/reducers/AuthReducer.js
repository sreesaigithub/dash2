import {
  SHOW_LOADING_ACTION,
  USER_AUTHENTICATE_REQUEST,
  USER_AUTHENTICATE_SUCCESS,
  USER_AUTHENTICATE_FAILURE,
  UPDATE_HEADER_TEXT,
  UPDATE_TIER_INFO,
} from "../../helper/constants";

const initialState = {
  loading: false,
  user: {
    userId: "",
    approvalRequestCount: 0,
    userName: "",
    groupName: "",
    roleName: "",
    isAuthorized: 0,
    roleId: null,
    message: null,
    menus: {},
    GroupActive: "",
    mbrroleId: null,
  },
  error: "",
  headerText: "",
  tierLevel: 1,
  tierName: "all",
};

const authReducer = (state = initialState, action) => {
  switch (action.type) {
    case USER_AUTHENTICATE_REQUEST:
      return { ...state, loading: true };
    case USER_AUTHENTICATE_SUCCESS:
      return { ...state, loading: false, user: action.payload, error: "" };
    case USER_AUTHENTICATE_FAILURE:
      return {
        ...state,
        loading: false,
        user: {},
        error: action.payload,
      };
    case UPDATE_HEADER_TEXT:
      return { ...state, headerText: action.payload };
    case SHOW_LOADING_ACTION:
      return { ...state, loading: action.payload };
    case UPDATE_TIER_INFO:
      return {
        ...state,
        tierLevel: action.payload.tierLevel,
        tierName: action.payload.tierName,
      };
    default:
      return state;
  }
};

export default authReducer;
