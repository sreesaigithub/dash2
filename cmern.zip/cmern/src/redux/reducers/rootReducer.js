import { combineReducers } from 'redux';
import authReducer from './AuthReducer';
import impactReducer from './ImpactTrackingReducer';


const rootReducer = combineReducers({
	authReducer,
    impactReducer
})

export default rootReducer;