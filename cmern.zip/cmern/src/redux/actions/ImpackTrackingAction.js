import { SET_MATRIX_SUMMARY_REPORT, TRACKING_STAGE_FILTER_UPDATE, TRACKING_JOBS_LOADING, TRACKING_STAGE_FILTER_RESET, RUN_STAGE_1_JOBS_UPDATE, RETRIEVE_HOME_JOBS_INFO, RETRIEVE_BALANCE_METRICS_INFO, STAGE_1_ROW_DATA_SELECTED, WEIGHT_DATA_FILE_NAME, RETRIEVE_OUTCOMES_TABLE_INFO, CLEAR_STAGE_1_ROW_DATA, RETRIEVE_VALUES_FILTER_INFO, IMPACT_TRACKING_ERROR, RETRIEVE_SMD_SUMMARY_INFO } from "../../helper/constants";
import { RUN_STAGE_2_JOB_UPDATE, RETRIEVE_METRIC_SUMMARY_INFO, RETRIEVE_COST_CURVE_INFO, RETRIEVE_PARALLEL_ADJUSTED_INFO, RETRIEVE_PARALLEL_UNADJUSTED_INFO, RETRIEVE_PARALLEL_METRIC_INFO, RETRIEVE_IMPACT_EVENTS_INFO } from "../../helper/constants";
import { DoGetCall, DoPostCall, exportAsCSV, multiGetRequest, } from './../../helper/util';
import { showLoading } from "./authAction";

export const getImpactStage1Run = (serviceName, params = '') => {
    return (dispatch) => {
        dispatch(showLoading(true));
        DoPostCall("fetchImpactDashBoardJobs", params, (success, data, error) => {
            if (success) {
                dispatch(retrieveJobsInfo());
                dispatch(runStage1JobsUpdate(data));
            } else {
                dispatch(failureErrorInfo(error));
            }
            dispatch(showLoading(false));
        });
    };
};

export const retrieveJobsInfo = () => {
    return (dispatch) => {
        dispatch(showLoading(true));
        const urls = ['fetchImpactDashBoardJobs', 'fetchImpactDashBoardJobs'];
        const params = ['', { status: 'complete' }];
        dispatch(successJobsInfo([]));
        multiGetRequest(urls, params, (success, response, error) => {
            if (success) {
                const res = response.map((resp) => resp.data);
                dispatch(successJobsInfo(res));
            } 
            dispatch(showLoading(false));
        });
    };
};

export const refreshJobsInfo = () => {
    return (dispatch) => {
        const urls = ['fetchImpactDashBoardJobs', 'fetchImpactDashBoardJobs'];
        const params = ['', { status: 'complete' }];
        multiGetRequest(urls, params, (success, response, error) => {
            if (success) {
                const res = response.map((resp) => resp.data);
                dispatch(successJobsInfo(res));
            }
        });
    };
};

export const successJobsInfo = (jobsInfo) => {
    return {
        type: RETRIEVE_HOME_JOBS_INFO,
        payload: jobsInfo,
    }
}

export const runStage1JobsUpdate = (jobsInfo) => {
    return {
        type: RUN_STAGE_1_JOBS_UPDATE,
        payload: jobsInfo,
    };
};

export const isLoading = () => {
    return {
        type: TRACKING_JOBS_LOADING,
    }
}

export const stageFilterReset = () => {
    return {
        type: TRACKING_STAGE_FILTER_RESET,
    }
}

export const clearStage1RowData = () => {
    return {
        type: CLEAR_STAGE_1_ROW_DATA,
    }
}

export const stageFilterUpdate = (filterInfo) => {
    return {
        type: TRACKING_STAGE_FILTER_UPDATE,
        payload: filterInfo,
    };
};


export const stage1RowSelected = (rowSelectedData) => {
    return {
        type: STAGE_1_ROW_DATA_SELECTED,
        payload: rowSelectedData,
    }
}

export const downloadWeightData = (jobId = '') => {
    if(!jobId) {
        return;
    }
    const fileName = WEIGHT_DATA_FILE_NAME.replace('<JOB_ID>', jobId);
    return (dispatch) => {
        dispatch(showLoading(true));
        DoGetCall('fetchStage1WeightData', '', { find: '<JOB_ID>', replace: jobId }, (success, response, error) => {
            dispatch(showLoading(false));
            if (success) {
                const { weight_data } = response;
                exportAsCSV(fileName, weight_data);
            } else {
                dispatch(failureErrorInfo(error));
            }
            dispatch(showLoading(false));
        });
    }
}

export const populationBalanceMetricsData = (jobId) => {
    if(!jobId) {
        return;
    }
    return (dispatch) => {
        dispatch(showLoading(true));
        dispatch(successBalanceMetricsInfo([]));
        DoGetCall('fetchBalanceMetricsData', '', { find: '<JOB_ID>', replace: jobId }, (success, response, error) => {
            dispatch(showLoading(false));
            if (success) {
                dispatch(successBalanceMetricsInfo(response));
            } else {
                dispatch(failureErrorInfo(error));
            }
        });
    };
    
}

export const successBalanceMetricsInfo = (metricsInfo) => {
    return {
        type: RETRIEVE_BALANCE_METRICS_INFO,
        payload: metricsInfo,
    }
}

export const getValuesFilter = (serviceName, params = '') => {
    return (dispatch) => {
        DoPostCall('fetchValuesFilterData', params, (success, data, error) => {
            if(success) {
                dispatch(successValuesFilterInfo(data));
            } else {
                dispatch(failureErrorInfo(error));
            }
        }
        )};
}

export const successValuesFilterInfo = (valuesFilterInfo) => {    
    return {
        type: RETRIEVE_VALUES_FILTER_INFO,
        payload: valuesFilterInfo,
    }
}

export const getOutComesTableData = (jobId) => {
    if(!jobId) {
        return;
    }
    return (dispatch) => {
        dispatch(showLoading(true));
        dispatch(successOutcomeTable([]));
        DoGetCall('fetchOutcomesTableData', '', { find: '<JOB_ID>', replace: jobId }, (success, response, error) => {
            dispatch(showLoading(false));
            if (success) {
                dispatch(successOutcomeTable(response));
            } else {
                dispatch(failureErrorInfo(error));
            }
        });
    };
}

export const successOutcomeTable = (outcomesInfo) => {
    return {
        type: RETRIEVE_OUTCOMES_TABLE_INFO,
        payload: outcomesInfo,
    }
}

export const failureErrorInfo = (errorInfo) => {
    return {
        type: IMPACT_TRACKING_ERROR,
        payload: errorInfo
    }
}

export const getSMDSummaryData = (jobId) => {
    if(!jobId) {
        return;
    }
    return (dispatch) => {
        dispatch(showLoading(true));
        dispatch(successSMDSummaryInfo([]));
        DoGetCall('fetchSMDSummaryData', '', { find: '<JOB_ID>', replace: jobId }, (success, response, error) => {
            dispatch(showLoading(false));
            if (success) {
                dispatch(successSMDSummaryInfo(response));
            } else {
                dispatch(failureErrorInfo(error));
            }
        });
    };
    
}

export const successSMDSummaryInfo = (SMDSummaryInfo) => {
    return {
        type: RETRIEVE_SMD_SUMMARY_INFO,
        payload: SMDSummaryInfo,
    }
}

export const getImpactStage2Run = (jobId) => {
    if(!jobId) {
        return;
    }
    return (dispatch) => {
        dispatch(showLoading(true));
        DoPostCall("impactDashboardStage2Data",  {}, (success, data, error) => {
            if (success) {
                dispatch(runStage2JobUpdate(data));
            } else {
                dispatch(failureErrorInfo(error));
            }
            dispatch(showLoading(false));
        }, {find: '<JOB_ID>', replace: jobId});
    };
};

export const runStage2JobUpdate = (jobsInfo) => {
    return {
        type: RUN_STAGE_2_JOB_UPDATE,
        payload: jobsInfo,
    };
};

export const matrixSummaryData = (jobId = '') => {
    if(!jobId) {
        return;
    }
    return (dispatch) => {
        dispatch(showLoading(true));
        dispatch(matrixSummaryReport([]));
        DoGetCall('fetchMatrixSummaryData', '', { find: '<JOB_ID>', replace: jobId }, (success, response, error) => {
            if (success) {
                dispatch(matrixSummaryReport(response.metric_summary));
            } else {
                dispatch(failureErrorInfo(error));
            }
            dispatch(showLoading(false));
        });
    }
}

export const matrixSummaryReport = (matrixJobResults) => {
    return {
        type: SET_MATRIX_SUMMARY_REPORT,
        payload: matrixJobResults,
    };
};
export const getMetricSummaryData = (jobId) => {
    if(!jobId) {
        return;
    }
    return (dispatch) => {
        dispatch(showLoading(true));
        DoGetCall('fetchMetricSummaryData', '', { find: '<JOB_ID>', replace: jobId }, (success, response, error) => {
            dispatch(showLoading(false));
            if (success) {
                dispatch(successMetricSummary(response));
            } else {
                dispatch(failureErrorInfo(error));
            }
        });
    };
}

export const successMetricSummary = (metricInfo) => {
    return {
        type: RETRIEVE_METRIC_SUMMARY_INFO,
        payload: metricInfo,
    }
}


export const getCostCurveData = (jobId) => {
    if(!jobId) {
        return;
    }
    return (dispatch) => {
        dispatch(showLoading(true));
        DoGetCall('fetchCostCurveData', '', { find: '<JOB_ID>', replace: jobId }, (success, response, error) => {
            dispatch(showLoading(false));
            if (success) {
                dispatch(successCostCurve(response));
            } else {
                dispatch(failureErrorInfo(error));
            }
        });
    };
}

export const successCostCurve = (costCurveInfo) => {
    return {
        type: RETRIEVE_COST_CURVE_INFO,
        payload: costCurveInfo,
    }
}

export const getParallelAdjustedData = (jobId) => {
    if(!jobId) {
        return;
    }
    return (dispatch) => {
        dispatch(showLoading(true));
        DoGetCall('fetchParallelAdjustedData', '', { find: '<JOB_ID>', replace: jobId }, (success, response, error) => {
            dispatch(showLoading(false));
            if (success) {
                dispatch(successParallelAdjusted(response));
            } else {
                dispatch(failureErrorInfo(error));
            }
        });
    };
}

export const successParallelAdjusted = (parallelAdjustedInfo) => {
    return {
        type: RETRIEVE_PARALLEL_ADJUSTED_INFO,
        payload: parallelAdjustedInfo,
    }
}

export const getParallelUnAdjustedData = (jobId) => {
    if(!jobId) {
        return;
    }
    return (dispatch) => {
        dispatch(showLoading(true));
        DoGetCall('fetchParallelUnAdjustedData', '', { find: '<JOB_ID>', replace: jobId }, (success, response, error) => {
            dispatch(showLoading(false));
            if (success) {
                dispatch(successParallelUnAdjusted(response));
            } else {
                dispatch(failureErrorInfo(error));
            }
        });
    };
}

export const successParallelUnAdjusted = (parallelUnAdjustedInfo) => {
    return {
        type: RETRIEVE_PARALLEL_UNADJUSTED_INFO,
        payload: parallelUnAdjustedInfo,
    }
}

export const getParallelMetricData = (jobId) => {
    if(!jobId) {
        return;
    }
    return (dispatch) => {
        dispatch(showLoading(true));
        DoGetCall('fetchParallelMetricData', '', { find: '<JOB_ID>', replace: jobId }, (success, response, error) => {
            dispatch(showLoading(false));
            if (success) {
                dispatch(successParallelMetric(response));
            } else {
                dispatch(failureErrorInfo(error));
            }
        });
    };
}

export const successParallelMetric = (parallelMetricInfo) => {
    return {
        type: RETRIEVE_PARALLEL_METRIC_INFO,
        payload: parallelMetricInfo,
    }
}

export const getImpactDashboardEventsData = () => {
    return (dispatch) => {
        dispatch(showLoading(true));
        DoGetCall('fetchImpactDashBoardEvents', '', { status: 'complete' }, (success, response, error) => {
            dispatch(showLoading(false));
            if (success) {
                dispatch(successEvents(response));
            } else {
                dispatch(failureErrorInfo(error));
            }
        });
    };
}

export const successEvents = (eventsInfo) => {
    return {
        type: RETRIEVE_IMPACT_EVENTS_INFO,
        payload: eventsInfo,
    }
}
