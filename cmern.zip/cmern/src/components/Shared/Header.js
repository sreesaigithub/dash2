import React, { useState, useEffect, useContext } from "react";
import { useSelector } from "react-redux";
import carelonLogo from "../../Images/elevance_2.png";
import coclogo from "../../Images/coc_logo_lightcircle.png";
import "./Header.css";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import { menuItems } from "../Shared/NavItems";
import MenuItems from "../Shared/MenuItems";
import AuthService from "../../services/authService";
import { authenticateuser } from "../../redux/actions/authAction";
import { AuthContext } from "../../providers/authProvider";
import { useDispatch } from "react-redux";
import ModalBox from "../Utility/ModalBox";

const Header = () => {
  let navigate = useNavigate();
  const [logoutDrop, setLogoutDrop] = useState(false);
  const authService = new AuthService();
  const userData = useSelector((state) => state.authReducer.user);
  const headerText = useSelector((state) => state.authReducer.headerText);
  const dispatch = useDispatch();
  const auth = useContext(AuthContext);
  const [mdlShow, setMdlShow] = useState(false);

  const [grpMdlShow, setGrpMdlShow] = useState(false);

  let userIdFromAuth = "";

  useEffect(() => {
    console.log("header");
    authService.getUser().then((resp) => {
      console.log(resp);
      console.log(resp["profile"]);
      console.log(resp["profile"]["sub"]);
      console.log(resp["profile"]["roles"]);

      var accessToken = resp["access_token"];
      var idToken = resp["id_token"];
      var groupNames = resp["profile"]["GroupNames"];
      var userId = resp["profile"]["sub"];
      var firstName = resp["profile"]["firstname"];
      var lastName = resp["profile"]["lastname"];
      userIdFromAuth = userId;

      let groupUpper;
      if (groupNames != undefined) {
        if (Array.isArray(groupNames)) {
          if (groupNames.length > 0) {
            groupUpper = groupNames.map((element) => {
              return element.toUpperCase();
            });
            console.log("accessToken from header page : ", accessToken);
            console.log("idToken from header page : ", idToken);
            if (accessToken != undefined && idToken != undefined) {
              console.log("tester");
              dispatch(
                authenticateuser(userId, groupUpper, firstName, lastName)
              );
            }
          } else {
            setGrpMdlShow(true);
          }
        } else {
          if (groupNames.length > 0) {
            groupUpper = [groupNames.toUpperCase()];
            console.log("accessToken from header page : ", accessToken);
            console.log("idToken from header page : ", idToken);
            if (accessToken != undefined && idToken != undefined) {
              console.log("tester");
              dispatch(
                authenticateuser(userId, groupUpper, firstName, lastName)
              );
            }
          } else {
            setGrpMdlShow(true);
          }
        }
      }
    });
  }, []);

  useEffect(() => {
    if (userData?.message != null && userData?.isAuthorized != 1) {
      setMdlShow(true);
    }
  }, [userData]);

  const handleOidcLogin = async () => {
    navigate("/private");
  };
  const handleLogout = async () => {
    auth.logout();
  };

  const closeModal = () => {
    setMdlShow(false);
    setGrpMdlShow(false);
    navigate("/");
    //window.location.replace("/cocwp");
  };
  return (
    <>
      <nav
        className="navbar fixed-top1 navbar-expand-lg1 navbar-light flex-wrap p-0 respNavbx"
        style={{
          backgroundColor: "#1a3673",
          boxShadow: "0px 5px 10px #1a3673",
        }}
      >
        <div className="container-fluid justify-content-center flex-column flex-lg-row justify-content-lg-between py-2 ps-4 pe-2">
          <div className="app-logo mt-2 mt-lg-0">
            <Link to="/">
              <img src={carelonLogo} alt="Elevance logo" width="100" />
            </Link>
            <span className="headerSeparator">|</span>
            <span
              style={{
                fontSize: "18px",
                position: "relative",
                top: "3px",
                display: "inline-block",
                color: "#ffffff",
              }}
            >
              <img src={coclogo} alt="COC LOGO" />
              &nbsp;COST OF CARE PLATFORM
            </span>
          </div>

          <div className="menu-bar">
            <ul className="top-level-menu loggedin-list menus align-items-baseline">
              {menuItems.map((menu, index) => {
                const depthLevel = 0;
                let clsName = "";

                if (
                  menu.title === "Home" ||
                  menu.title === "Dashboard" ||
                  menu.title === "Support"
                ) {
                  clsName = "";
                } else if (
                  userData?.menus != null &&
                  Object.values(userData?.menus).indexOf(menu.title) > -1 &&
                  userData?.isAuthorized == 1
                ) {
                  clsName = "";
                } else {
                  clsName = "hide";
                }

                return (
                  <MenuItems
                    items={menu}
                    menuShow={clsName}
                    key={index}
                    depthLevel={depthLevel}
                    userRes={userData?.menus}
                  />
                );
              })}

              {userData?.isAuthorized !== 1 && (
                <>
                  <li className="pe-0">
                    <a
                      className="btn btn-primary"
                      onClick={handleOidcLogin}
                      style={{ lineHeight: "initial" }}
                    >
                      Login
                    </a>
                  </li>
                  <li className="nav-item">
                    <Link
                      to="/register"
                      className="btn btn-primary"
                      style={{ lineHeight: "initial" }}
                    >
                      Register
                    </Link>
                  </li>
                </>
              )}

              {userData?.isAuthorized === 1 && userData?.userName && (
                <>
                  <li
                    className="nav-item dropdown-user"
                    onMouseEnter={() => setLogoutDrop(true)}
                    onMouseLeave={() => setLogoutDrop(false)}
                  >
                    <Link
                      className="nav-link dropdown-toggle user-name"
                      to="#"
                      id="navbarDropdown"
                      role="button"
                      data-toggle="dropdown"
                      aria-haspopup="true"
                      aria-expanded="false"
                    >
                      {userData?.userName} |{" "}
                      <span className="font9">
                        {userData?.groupName} | {userData?.roleName}
                      </span>
                      <i
                        className="fa fa-user-circle-o fa-user-circle-o-18 ms-2"
                        aria-hidden="true"
                      ></i>
                    </Link>
                    {logoutDrop && (
                      <div
                        className="dropdown-menu menu-presentation d-block"
                        aria-labelledby="navbarDropdown"
                        onMouseLeave={() => setLogoutDrop(false)}
                      >
                        <div className="user-setting">
                          <Link to="#" className="dropdown-item">
                            Profile
                          </Link>
                          <Link to="#" className="dropdown-item">
                            Manage
                          </Link>
                        </div>
                        <div className="logout-section">
                          <Link
                            className="dropdown-item"
                            to="#"
                            onClick={handleLogout}
                          >
                            Logout
                          </Link>
                        </div>
                      </div>
                    )}
                  </li>
                </>
              )}
            </ul>

            {/* 

            {userData?.isAuthorized === 1 && userData?.userName && (
              <ul
                className="top-level-menu loggedin-list"
                onMouseEnter={() => setLogoutDrop(true)}
                onMouseLeave={() => setLogoutDrop(false)}
              >
                <li className="nav-item dropdown-user">
                  <Link
                    className="nav-link dropdown-toggle user-name"
                    to="#"
                    id="navbarDropdown"
                    role="button"
                    data-toggle="dropdown"
                    aria-haspopup="true"
                    aria-expanded="false"
                  >
                    {userData?.userName} |{" "}
                    <span className="font9">
                      {userData?.groupName} | {userData?.roleName}
                    </span>
                    <i
                      className="fa fa-user-circle-o fa-user-circle-o-18 ms-2"
                      aria-hidden="true"
                    ></i>
                  </Link>
                  {logoutDrop && (
                    <div
                      className="dropdown-menu menu-presentation d-block"
                      aria-labelledby="navbarDropdown"
                    >
                      <div className="user-setting">
                        <Link to="#" className="dropdown-item">
                          Profile
                        </Link>
                        <Link to="#" className="dropdown-item">
                          Manage
                        </Link>
                      </div>
                      <div className="logout-section">
                        <Link
                          className="dropdown-item"
                          to="#"
                          onClick={handleLogout}
                        >
                          Logout
                        </Link>
                      </div>
                    </div>
                  )}
                </li>
              </ul>
            )}
             */}
          </div>

          {/* 
          <div className="float-lg-right mb-2 mb-lg-0 font-14">
            {userData?.isAuthorized !== 1 && (
              <ul className="navbar-nav flex-row">
                <li>
                  <button
                    className="btn btn-primary me-2"
                    onClick={handleOidcLogin}
                  >
                    Login
                  </button>
                </li>
                <li className="nav-item">
                  <Link to="/register" className="btn btn-primary">
                    Register
                  </Link>
                </li>
              </ul>
            )}

            {userData?.isAuthorized == 1 && userData?.approvalRequestCount > 0 && (
              <ul className="navbar-nav flex-row">
                <li className="nav-item">
                  <a
                    href="/Admin/Users"
                    data-toggle="tooltip"
                    data-trigger="click hover"
                    title="User Registration Approvals Pending!"
                    data-template='<div class="tooltip notify-tip" role="tooltip"><div class="arrow"></div><div class="tooltip-inner"></div></div>'
                    class="notification btn m-0 position-relative pointer"
                  >
                    <span className="material-icons">notifications_active</span>
                    <span className="noOfRequests position-absolute top-0">
                      userData?.approvalRequestCount
                    </span>
                  </a>
                </li>
              </ul>
            )}
            {userData?.isAuthorized == 1 &&
              userData?.approvalRequestCount <= 0 && (
                <ul className="navbar-nav flex-row">
                  <li className="nav-item d-flex align-items-center">
                    <a
                      href="/ContactUs/ContactUs"
                      className="m-0 position-relative pointer"
                    >
                      <span className="material-icons">help_outline</span>
                    </a>
                  </li>
                </ul>
              )}
          </div> */}
        </div>

        {/* <div className="menu-bar w-100">
          <ul className="top-level-menu loggedin-list menus">
            {menuItems.map((menu, index) => {
              const depthLevel = 0;
              let clsName = "";

              if (
                menu.title === "Home" ||
                menu.title === "Dashboard" ||
                menu.title === "Support"
              ) {
                clsName = "";
              } else if (
                userData?.menus != null &&
                Object.values(userData?.menus).indexOf(menu.title) > -1 &&
                userData?.isAuthorized == 1
              ) {
                clsName = "";
              } else {
                clsName = "hide";
              }

              return (
                <MenuItems
                  items={menu}
                  menuShow={clsName}
                  key={index}
                  depthLevel={depthLevel}
                  userRes={userData?.menus}
                />
              );
            })}
          </ul>

          {userData?.isAuthorized === 1 && userData?.userName && (
            <ul
              className="top-level-menu loggedin-list"
              onMouseEnter={() => setLogoutDrop(true)}
              onMouseLeave={() => setLogoutDrop(false)}
            >
              <li className="nav-item dropdown-user">
                <Link
                  className="nav-link dropdown-toggle user-name"
                  to="#"
                  id="navbarDropdown"
                  role="button"
                  data-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded="false"
                >
                  {userData?.userName} |{" "}
                  <span className="font9">
                    {userData?.groupName} | {userData?.roleName}
                  </span>
                  <i
                    className="fa fa-user-circle-o fa-user-circle-o-18 ms-2"
                    aria-hidden="true"
                  ></i>
                </Link>
                {logoutDrop && (
                  <div
                    className="dropdown-menu menu-presentation d-block"
                    aria-labelledby="navbarDropdown"
                  >
                    <div className="user-setting">
                      <Link to="#" className="dropdown-item">
                        Profile
                      </Link>
                      <Link to="#" className="dropdown-item">
                        Manage
                      </Link>
                    </div>
                    <div className="logout-section">
                      <Link
                        className="dropdown-item"
                        to="#"
                        onClick={handleLogout}
                      >
                        Logout
                      </Link>
                    </div>
                  </div>
                )}
              </li>
            </ul>
          )}
        </div> */}
      </nav>
      {mdlShow && userData?.isAuthorized != 1 && (
        <ModalBox
          modalShow={mdlShow}
          handleClose={closeModal}
          modalData={{
            title: "Login",
            content: userData?.message,
          }}
        >
          <a
            href="#"
            className="btn btn-success"
            data-dismiss="modal"
            onClick={() => {
              closeModal();
            }}
          >
            OK
          </a>
        </ModalBox>
      )}

      {grpMdlShow && (
        <ModalBox
          modalShow={grpMdlShow}
          handleClose={closeModal}
          modalData={{
            title: "User Authentication Failed ",
            content: `
            <div style="font-family: 'ElevanceSansLight';margin-left: 20px;">Please submit <a href="https://elevancehealth.service-now.com/ess?id=ant_sc_cat_item&sys_id=e91ff2b2dbca47008567fd7aae961946" target="_blank">Access Request Form</a>.
            <span style="font-family: 'ElevanceSansLightItalic';font-size:15px;display: block;text-transform: lowercase;">Select Request Type as New, Domain as US (Prod) and DEVAD (non Prod), Group Name as coc_devops or coc_app_users or coc_pbi_user </span> </div>`,
          }}
        >
          <a
            href="#"
            className="btn btn-success"
            data-dismiss="modal"
            onClick={() => {
              closeModal();
            }}
          >
            OK
          </a>
        </ModalBox>
      )}
    </>
  );
};

export default Header;
