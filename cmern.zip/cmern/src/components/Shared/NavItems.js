﻿export const menuItems1 = [
  {
    title: "Home",
    path: "/",
  },

  // {
  //     title: "Business",
  //     submenu: [
  //         {
  //             title: "Load Summary",
  //             path: "/business/loadsummary"
  //         },
  //         {
  //             title: "Cut Maintenance",
  //             submenu: [
  //                 { title: "Triangle", path: "/business/cutmaintenance/triangle" },
  //                 { title: "Sum", path: "/business/cutmaintenance/sum" }
  //             ]
  //         },
  //         {
  //             title: "Grouping",
  //             path: "/business/grouping"
  //         },
  //         {
  //             title: "Submit Grouping",
  //             path: "/business/submitgrouping"
  //         },
  //         {
  //             title: "Download Center",
  //             path: "/business/downloadcenter"
  //         },
  //         {
  //             title: "My File Gateway",
  //             path: "/business/myfilegateway"
  //         },

  //     ]
  // },
  {
    title: "DevOps",
    submenu: [
      {
        title: "AdminOps",
        submenu: [
          { title: "Roles & Groups", path: "/devops/adminops/rolesgroups" },
          { title: "Users", path: "/devops/adminops/users" },
        ],
      },
    ],
  },
  {
    title: "Dashboard",
    path: "/dashboard",
  },
  {
    title: "Support",
    path: "/support",
  },
];

export const menuItems = [
  {
    title: "Home",
    path: "/",
  },
  {
    title: "Dashboard",
    path: "/dashboard",
  },
  {
    title: "Support",
    path: "/support",
  },
  {
    title: "DevOps",
    submenu: [
      {
        title: "Admin Ops",
        submenu: [
          {
            title: "Roles and Groups",
            path: "/devops/adminops/rolesgroups",
          },
          { title: "Users", path: "/devops/adminops/users" },
        ],
      },
    ],
  },
  // {
  //   title: "Reports",
  //   path: "/reportsdashboard",
  // },
];
