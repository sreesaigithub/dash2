import React, { useRef, useContext } from "react";
import IdleTimer from "react-idle-timer";
import { AuthContext } from "../../providers/authProvider";
import { useSelector } from "react-redux";

function IdleTimerContainer() {
  const idleTimerRef = useRef(null);
  const auth = useContext(AuthContext);
  const userData = useSelector((state) => state.authReducer.user);
  const onIdle = () => {
    if (userData.isAuthorized === 1) {
      console.log("User is idle for 15 minutes and logged in. Logging out");
      auth.logout();
    } else {
      console.log("User is not logged in and idle");
    }
  };

  return (
    <>
      <IdleTimer ref={idleTimerRef} timeout={1000 * 60 * 15} onIdle={onIdle} />
    </>
  );
}

export default IdleTimerContainer;
