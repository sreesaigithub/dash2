﻿import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { useDispatch } from "react-redux";
import { updateheadertext } from "../../redux/actions/authAction";

import Dropdown from "./Dropdown";

const MenuItems = ({ items, menuShow, depthLevel, userRes }) => {
  const [dropdown, setDropdown] = useState(false);

  let ref = useRef();
  const dispatch = useDispatch();

  useEffect(() => {
    const handler = (event) => {
      if (dropdown && ref.current && !ref.current.contains(event.target)) {
        setDropdown(false);
      }
    };
    document.addEventListener("mousedown", handler);
    document.addEventListener("touchstart", handler);
    return () => {
      // Cleanup the event listener
      document.removeEventListener("mousedown", handler);
      document.removeEventListener("touchstart", handler);
    };
  }, [dropdown]);

  const onMouseEnter = () => {
    window.innerWidth > 960 && setDropdown(true);
  };

  const onMouseLeave = () => {
    window.innerWidth > 960 && setDropdown(false);
  };

  return (
    <li
      className={`menu-items nav-item  hideFromNav ${menuShow} ${
        items.submenu ? "multiple" : ""
      }`}
      ref={ref}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
    >
      {items.submenu ? (
        <>
          {/* <span className="top-arrow"></span> */}
          <Link
            type="button"
            to="#"
            aria-haspopup="menu"
            role="button"
            aria-expanded={dropdown ? "true" : "false"}
            onClick={() => {
              setDropdown((prev) => !prev);
              dispatch(updateheadertext(""));
            }}
            className={`hideFromNav ${menuShow}`}
          >
            {items.title}{" "}
            {depthLevel > 0 ? (
              <span className="arrow-point-right"></span>
            ) : (
              <span className="arrow" />
            )}
          </Link>
          <Dropdown
            depthLevel={depthLevel}
            submenus={items.submenu}
            dropdown={dropdown}
            userMenus={userRes}
          />
        </>
      ) : (
        <Link
          to={items.path}
          onClick={() => {
            dispatch(updateheadertext(""));
          }}
          className={`hideFromNav ${menuShow}`}
        >
          {items.title}
        </Link>
      )}
    </li>
  );
};

export default MenuItems;
