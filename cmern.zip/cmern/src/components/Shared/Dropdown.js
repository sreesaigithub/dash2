﻿import MenuItems from "./MenuItems";
const Dropdown = ({ submenus, dropdown, depthLevel, userMenus }) => {
  depthLevel = depthLevel + 1;
  const dropdownClass = depthLevel > 1 ? "dropdown-submenu" : "";
  return (
    <ul className={`dropdown ${dropdownClass} ${dropdown ? "show" : ""}`}>
      {submenus.map((submenu, index) => {
        let clsNameFromMulti = "";

        if (
          userMenus != null &&
          Object.values(userMenus).indexOf(submenu.title) > -1
        ) {
          clsNameFromMulti = "";
        } else {
          clsNameFromMulti = "hide";
        }

        return (
          <MenuItems
            items={submenu}
            menuShow={clsNameFromMulti}
            key={index}
            depthLevel={depthLevel}
            userRes={userMenus}
          />
        );
      })}
    </ul>
  );
};

export default Dropdown;
