import React from "react";
import { Link } from "react-router-dom";

export default function Footer() {
  const ftstyles = {
    marginLeft: "45px",
    fontSize: "12px",
  };
  return (
    <div className="footer text-muted container homeFooter">
      <span style={ftstyles}>
        &copy; {new Date().getFullYear()} <strong>IMPORTANT</strong> : This
        Application is intended for internal use only. By logging in, you are
        accepting these terms and agreeing to use this Application in accordance
        with the elevance health licensing agreement -{" "}
        <Link to="/privacy">Privacy</Link>
      </span>
    </div>
  );
}
