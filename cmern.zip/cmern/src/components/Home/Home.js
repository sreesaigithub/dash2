import React, { useState, useEffect } from "react";

import { Link, useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import {
  updateheadertext,
  updatetierInfo,
} from "../../redux/actions/authAction";

import executive from "../../Images/COC-Executive.png";
import COCRFA from "../../Images/COC-Restated-Financial.png";
import COCLanding from "../../Images/COC-CostOfCare.png";
import Capitation from "../../Images/COC-Capitation.png";
import SpecialtyRx from "../../Images/COC-Specialty-Rx.png";

import commercial from "../../Images/COC-Commercial.png";
import Medicaid from "../../Images/COC-Medicaid.png";
import Medicare from "../../Images/COC-Medicare.png";

import COCFGS from "../../Images/COC-FGS.png";

import CoCDashboard from "../Dashboard/COC/CoCDashboard";
import ExecutiveBoard from "../Dashboard/Executive/ExecutiveBoard";
import RFADashboard from "../Dashboard/RFA/RFADashboard";
import CapitationDashboard from "../Dashboard/Capitation/CapitationDashboard";
import SpecialtyRxDashboard from "../Dashboard/SpecialtyRx/SpecialtyRxDashboard";
import DynamicDboardList from "./DynamicDboardList";

import CommercialPage from "../Dashboard/Commercial/Commercial";
import MedicaidPage from "../Dashboard/Medicaid/Medicaid";
import MedicarePage from "../Dashboard/Medicare/Medicare";
import FGS from "../Dashboard/FGS/Fgs";
import { useSelector } from "react-redux";

function Home() {
  let navigate = useNavigate();
  const dispatch = useDispatch();
  const userData = useSelector((state) => state.authReducer.user);
  const tierName = useSelector((state) => state.authReducer.tierName);
  const tierLevel = useSelector((state) => state.authReducer.tierLevel);
  console.log("State:::::::::", tierName);
  console.log("State:::::::::", tierLevel);
  const [showLOBView, setShowLOBView] = useState(false);

  useEffect(() => {
    document.body.style.backgroundColor = "#e3f4fd";
    return function cleanup() {
      document.body.style.backgroundColor = "#ffffff";
    };
  }, []);

  const handleDboardClick = (txt) => {
    navigate("/ExecutiveDashboard");
    dispatch(updateheadertext(txt));
  };

  const handlePowerboardClick = (txt) => {
    navigate("/powerbi");
    dispatch(updateheadertext(txt));
  };

  const handleHomeClick = () => {
    dispatch(
      updatetierInfo({
        tierLevel: tierLevel > 1 ? tierLevel - 1 : tierLevel,
        tierName: tierName,
      })
    );
  };

  const svgStyles = {
    color: "#1559cd",
    height: "20px",
    marginLeft: "20px",
    marginRight: "20px",
    width: "20px",
    fill: "currentColor",
  };
  return (
    <>
      <div
        className="dboardLanding"
        style={{
          padding: "10px",
          overflow: "auto",
          minHeight: "700px",
          // backgroundColor: "#E1EDFF",
          backgroundColor: "#E3F4FD",
          paddingLeft: "0",
          paddingTop: "19px",
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "end",
            paddingRight: "24px",
          }}
        >
          {/* Search */}
          <div className="dboardParentSearchdiv">
            <div className="dboardSearch">
              <svg viewBox="0 0 32 32" style={svgStyles} className="">
                <path d="M31.805 30.861l-12.012-12.012c1.781-2.003 2.873-4.631 2.873-7.516 0-6.249-5.084-11.333-11.333-11.333s-11.333 5.084-11.333 11.333c0 6.249 5.084 11.333 11.333 11.333 2.885 0 5.513-1.092 7.516-2.875l12.012 12.012c0.131 0.131 0.301 0.196 0.472 0.196s0.341-0.065 0.472-0.195c0.26-0.26 0.26-0.683 0-0.944zM1.333 11.333c0-5.513 4.485-10 10-10s10 4.487 10 10c0 5.515-4.485 10-10 10s-10-4.485-10-10z"></path>
              </svg>
              <input
                type="text"
                className="dboardinputSearch"
                placeholder="What are you looking for today?"
              />
            </div>
          </div>
        </div>

        {/* Content box */}
        <div className="d-content-box d-flex justify-content-center">
          <div className="wrapper">
            <div className="caption">
              {tierLevel > 1 && (
                <i
                  className="fa fa-arrow-circle-left dashboardHomeIcon"
                  onClick={handleHomeClick}
                  aria-hidden="true"
                ></i>
              )}
              <DynamicDboardList />

              <a
                className="referencInfoLink trainingsLink"
                target="_blank"
                href="https://share.antheminc.com/teams/cocaportal/SitePages/CoC%20Analytics%20Platform.aspx"
              >
                <div className="referenceLinkInnerParent">
                  <span>Access and Training</span>
                </div>
              </a>
            </div>

            {/**All wrappers */}
            {!showLOBView && (
              <div
                className={`icon-wrapper all-wrapper dashboardTypeView ${
                  tierLevel === 1 ? "d-flex" : "d-none"
                }`}
              >
                {/* Show impact tracking if member role id is 3, for others show all dashboards */}

                {userData.mbrroleId === 3 ? (
                  <div
                    className={`icon ${
                      userData.isAuthorized != 1 ? "disabled" : ""
                    }`}
                  >
                    <a to="/impacttracking" href="/cocwp/impacttracking">
                      <img
                        className="costofcareicon"
                        src={COCFGS}
                        alt="Dashboard Icon"
                      />
                      <span className="costofcareiconspan">
                        Impact Tracking
                        <br />{" "}
                      </span>
                    </a>
                  </div>
                ) : (
                  <>
                    <div
                      className={`icon ${
                        userData.isAuthorized != 1 ? "disabled" : ""
                      }`}
                    >
                      <a
                        onClick={() => handleDboardClick("Executive Dashboard")}
                      >
                        <img src={executive} alt="Executive Icon" />
                        <span>Executive</span>
                      </a>
                    </div>

                    <div
                      className={`icon ${
                        userData.isAuthorized != 1 ? "disabled" : ""
                      }`}
                    >
                      <a
                        onClick={() => {
                          dispatch(
                            updatetierInfo({ tierLevel: 2, tierName: "RFA" })
                          );
                        }}
                      >
                        <img src={COCRFA} alt="RFA Icon" />
                        <span>Restated Financial</span>
                      </a>
                    </div>
                    <div
                      className={`icon ${
                        userData.isAuthorized != 1 ? "disabled" : ""
                      }`}
                    >
                      <a
                        onClick={() => {
                          dispatch(
                            updatetierInfo({ tierLevel: 2, tierName: "COC" })
                          );
                        }}
                      >
                        <img src={COCLanding} alt="COC Icon" />
                        <span>Cost Of Care</span>
                      </a>
                    </div>

                    <div
                      className={`icon ${
                        userData.isAuthorized != 1 ? "disabled" : ""
                      }`}
                    >
                      <a
                        onClick={() => {
                          dispatch(
                            updatetierInfo({
                              tierLevel: 2,
                              tierName: "Capitation",
                            })
                          );
                        }}
                      >
                        <img src={Capitation} alt="Capitation Icon" />
                        <span>Capitation</span>
                      </a>
                    </div>

                    <div
                      className={`icon ${
                        userData.isAuthorized != 1 ? "disabled" : ""
                      }`}
                    >
                      <a
                        onClick={() => {
                          dispatch(
                            updatetierInfo({
                              tierLevel: 2,
                              tierName: "SpecialtyRx",
                            })
                          );
                        }}
                      >
                        <img src={SpecialtyRx} alt="SpecialityRx Icon" />
                        <span>Speciality Rx</span>
                      </a>
                    </div>
                  </>
                )}
              </div>
            )}

            {showLOBView && (
              <div
                className={`icon-wrapper all-wrapper LOBTypeView ${
                  tierLevel === 1 ? "d-flex" : "d-none"
                }`}
              >
                <div
                  className={`icon ${
                    userData.isAuthorized != 1 ? "disabled" : ""
                  }`}
                >
                  <a
                    onClick={() => {
                      dispatch(
                        updatetierInfo({
                          tierLevel: 2,
                          tierName: "Commercial",
                        })
                      );
                    }}
                  >
                    <img src={commercial} alt="commercial Icon" />
                    <span>Commercial</span>
                  </a>
                </div>

                <div
                  className={`icon ${
                    userData.isAuthorized != 1 ? "disabled" : ""
                  }`}
                >
                  <a
                    onClick={() => {
                      dispatch(
                        updatetierInfo({
                          tierLevel: 2,
                          tierName: "Medicaid",
                        })
                      );
                    }}
                  >
                    <img src={Medicaid} alt="Medicaid Icon" />
                    <span>Medicaid</span>
                  </a>
                </div>

                <div
                  className={`icon ${
                    userData.isAuthorized != 1 ? "disabled" : ""
                  }`}
                >
                  <a
                    onClick={() => {
                      dispatch(
                        updatetierInfo({
                          tierLevel: 2,
                          tierName: "Medicare",
                        })
                      );
                    }}
                  >
                    <img src={Medicare} alt="Medicare Icon" />
                    <span>Medicare</span>
                  </a>
                </div>

                <div
                  className={`icon ${
                    userData.isAuthorized != 1 ? "disabled" : ""
                  }`}
                >
                  <a
                    onClick={() => {
                      dispatch(
                        updatetierInfo({
                          tierLevel: 2,
                          tierName: "FGS",
                        })
                      );
                    }}
                  >
                    <img src={COCFGS} alt="COCFGS Icon" />
                    <span>FGS</span>
                  </a>
                </div>
              </div>
            )}

            {/* Showing Switch button when logged in and mbrroled is not impact tracking (#3) */}
            {userData.isAuthorized == 1 && userData.mbrroleId !== 3 && (
              <div
                className={`icon-wrapper all-wrapper ${
                  tierLevel === 1 ? "d-flex" : "d-none"
                }`}
              >
                <div className="switchBtn">
                  <a onClick={() => setShowLOBView(!showLOBView)}>
                    <span>
                      {showLOBView
                        ? "Switch to Dashboard Type View"
                        : "Switch to Line of Business (LOB) View"}
                    </span>
                  </a>
                </div>
              </div>
            )}
            {tierName === "COC" && <CoCDashboard />}
            {tierName === "COC_VisualCare" && <CoCDashboard />}
            {tierName === "COC_Matrix" && <CoCDashboard />}
            {tierName === "COC_Clinical" && <CoCDashboard />}
            {tierName === "COC_Covid" && <CoCDashboard />}
            {tierName === "COC_Oncology" && <CoCDashboard />}
            {tierName === "Executive" && <ExecutiveBoard />}
            {tierName === "RFA" && <RFADashboard />}
            {tierName === "Capitation" && <CapitationDashboard />}
            {tierName === "SpecialtyRx" && <SpecialtyRxDashboard />}

            {tierName === "Commercial" && <CommercialPage />}
            {tierName === "Medicaid" && <MedicaidPage />}
            {tierName === "Medicare" && <MedicarePage />}
            {tierName === "FGS" && <FGS />}
          </div>
        </div>
      </div>
    </>
  );
}

export default Home;
