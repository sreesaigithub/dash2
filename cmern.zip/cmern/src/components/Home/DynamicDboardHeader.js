import React from "react";

function DynamicDboardHeader({ headertext, subcontent }) {
  return (
    <>
      <h1>{headertext}</h1>
      <h6>{subcontent}</h6>
    </>
  );
}

export default DynamicDboardHeader;
