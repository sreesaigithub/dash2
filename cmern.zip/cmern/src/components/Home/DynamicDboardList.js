import React from "react";
import DynamicDboardHeader from "./DynamicDboardHeader";
import { useSelector } from "react-redux";

function DynamicDboardList() {
  const tierName = useSelector((state) => state.authReducer.tierName);
  const tierLevel = useSelector((state) => state.authReducer.tierLevel);
  return (
    <>
      {tierLevel == 1 && (
        <DynamicDboardHeader
          headertext="Cost of Care Platform"
          subcontent=" Cost of Care Platform is a digitally enabled analytics platform
                to serve as a single source of truth for COC analytics across
                the enterprise. The COC Platform provides self service and
                interactive visualizations, insight-driven recommendations and
                effectiveness measurements of initiatives, capabilities include
                self service interactive dashboards, excel based pivots for
                ad-hoc analysis and deeper drill downs to member and claim line
                level insights."
        />
      )}

      {tierLevel == 2 && tierName === "Executive" && (
        <DynamicDboardHeader
          headertext="Executive Dashboards"
          subcontent="Contain 63 months of Restated Summary data including Budget with a special focus on managemnt of Revenue, Expense, Gross Margin, and Member months against budget expectations."
        />
      )}

      {tierLevel == 2 && tierName === "RFA" && (
        <DynamicDboardHeader
          headertext="Restated Financial Dashboards"
          subcontent="Contain 63 months of Restated Expenses (related to Claims, Capitation, NST, IBNR) with related Revenue and Membership, allowing for additional calculations such as MLR and Gross Margin."
        />
      )}

      {tierLevel == 2 &&
        (tierName === "COC" ||
          tierName === "COC_VisualCare" ||
          tierName === "COC_Matrix" ||
          tierName === "COC_Clinical" ||
          tierName === "COC_Covid" ||
          tierName === "COC_Oncology") && (
          <DynamicDboardHeader
            headertext="Cost of Care Dashboards"
            subcontent="Home of all dahboards based on the Cost of Care Model. Choose between Visuals (Graphs) vs Matrix formats (Columns and rows), Clinical Conditions and Covid 19 topics."
          />
        )}
      {tierLevel == 3 && tierName === "COC_VisualCare" && (
        <DynamicDboardHeader
          headertext="Cost of Care Dashboards"
          subcontent="Contain 39 months of Claim Line- and Member Level-Detail to facilitate efficient analysis for management of Cost of Care; contains a multitude of dimensions across 8 kinds of providers, DRG, APC, Diagnosis, Procedure, Claim Condition, Attribution, Readmissions, Member Duration, Inpatient Maternity, SDOH, CM/DM, and more."
        />
      )}
      {tierLevel == 3 && tierName === "COC_Matrix" && (
        <DynamicDboardHeader
          headertext="Matrix Dashboards"
          subcontent="Contain 39 months of Market specific Cost of Care data aimed at representing data in table-driven formats with key summary visuals."
        />
      )}

      {tierLevel == 3 && tierName === "COC_Clinical" && (
        <DynamicDboardHeader
          headertext="Clinical Conditions Dashboards"
          subcontent="Contain 39 months of data focused on the prevalence of disease and the conditions among various populations, Benefit Plans, Market Business Units, Age Groups and Gender. Prevalence refers to the proportion of persons who have a condition or characteristic at or during a particular time period."
        />
      )}

      {tierLevel == 3 && tierName === "COC_Covid" && (
        <DynamicDboardHeader
          headertext="Covid 19 Dashboards"
          subcontent="Contain 39 months of Claim Line Detail to facilitate a focused look at Covid 19 Cost of Care management."
        />
      )}
      {tierLevel == 3 && tierName === "COC_Oncology" && (
        <DynamicDboardHeader
          headertext="Oncology Dashboards"
          subcontent="Oncology Dashboards augment COC dashboard content with Prevalence of Oncology via Claim Condition Body System, Oncology Therapy Group, and Oncology Treatment Type Dimensionality to explicitly focus on Oncology Scope. All dimensions at Claim Line- and Member Level-Detail from COC remain amidst this Oncology focus."
        />
      )}

      {tierLevel == 2 && tierName === "Capitation" && (
        <DynamicDboardHeader
          headertext="Capitation Dashboards"
          subcontent="Contain 39 months of standalone Capitation; enables provider capitation payment and trend data just like the RFR environment without NST yet with much more granularity.  Membership ties to CoC and RFR dashboards."
        />
      )}

      {tierLevel == 2 && tierName === "SpecialtyRx" && (
        <DynamicDboardHeader
          headertext="Specialty Rx Dashboard"
          subcontent="Contains 24 months of Specialty Pharmacy drug data blending Medical and Pharmacy sources to identify specialty spend, trends and distribution by Site of Care and Drug Indications. Specialty Pharmacy Drilldown Dashboard (SPDD) has the capability to provide claim line level detail for any drug or indication."
        />
      )}
      {tierLevel == 2 && tierName === "Commercial" && (
        <DynamicDboardHeader
          headertext="Commercial Dashboards"
          subcontent="The Dashboards below are available across the breadth of Commercial Business."
        />
      )}

      {tierLevel == 2 && tierName === "Medicaid" && (
        <DynamicDboardHeader
          headertext="Medicaid Dashboards"
          subcontent="The Dashboards below are available across the breadth of Medicaid Business."
        />
      )}

      {tierLevel == 2 && tierName === "Medicare" && (
        <DynamicDboardHeader
          headertext="Medicare Dashboards"
          subcontent="The Dashboards below are available across the breadth of Medicare Business."
        />
      )}

      {tierLevel == 2 && tierName === "FGS" && (
        <DynamicDboardHeader
          headertext="FGS Dashboards"
          subcontent="The Dashboards below are available across the breadth of FGS Business."
        />
      )}
    </>
  );
}

export default DynamicDboardList;
