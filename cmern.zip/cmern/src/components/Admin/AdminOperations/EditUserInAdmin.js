﻿import React, { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import ModalBox from "../../Utility/ModalBox";
import Spinner from "../../Dashboard/ExecutiveDashboard/Overview/spinner";
import axios from "axios";

export default function EditUserInAdmin() {
  const [editUserData, setEditUserData] = useState({
    USERID: "",
    FIRST_NAME: "",
    LAST_NAME: "",
    ACCESS_TYPE: "",
    GROUP_NAME: "",
    ROLE_NAME: "",
  });
  const [Groupname, setGroupname] = useState([]);
  const [Role, setRole] = useState([]);
  const [Accesstype, setAccesstype] = useState([]);
  const [show, setShow] = useState(false);
  const [parentModalData, setParentModalData] = useState({});
  const [loadingMaster, setLoadingMaster] = useState(false);

  let location = useLocation();
  let userIdChange = location.state.id;
  let navigate = useNavigate();

  //const baseUrl = window.__RUNTIME_CONFIG__.REACT_APP_BASE_API_USER_MGNT_URL;
  //const baseUrl = "http://localhost:8080/cocwp/api";
  const baseUrl = window.__RUNTIME_CONFIG__.REACT_APP_BASE_API_USER_MGNT_URL;

  useEffect(() => {
    axios.get(`${baseUrl}/users/accessList`).then((res) => {
      setAccesstype(res.data);
      setEditUserData({ ...editUserData, ACCESS_TYPE: res.data });
    });
  }, []);

  useEffect(() => {
    axios.get(`${baseUrl}/users/groupsList`).then((res) => {
      setGroupname(res.data);
      setEditUserData({ ...editUserData, GROUP_NAME: res.data });
    });
  }, []);

  useEffect(() => {
    axios.get(`${baseUrl}/users/roleList`).then((res) => {
      setRole(res.data);
      setEditUserData({ ...editUserData, ROLE_NAME: res.data });
    });
  }, []);

  useEffect(() => {
    setLoadingMaster(true);
    axios
      .get(`${baseUrl}/users/singleProcessedUser?userId=${userIdChange}`)
      .then((res) => {
        const userData = res.data;
        setEditUserData(userData);
        setLoadingMaster(false);
      });
  }, [location]);
  const handleInputChange = (e) => {
    setEditUserData({
      ...editUserData,
      [e.target.name]: e.target.value,
    });
  };

  const updateUser = (e) => {
    e.preventDefault();
    console.log(editUserData);
    axios({
      method: "put",
      url: `${baseUrl}/users/updateProcessedUser/${userIdChange}`,
      data: editUserData,
    }).then((response) => setParentModalData(response.data), setShow(true));
  };

  const closeModal = () => {
    setShow(false);
    navigate("../devops/adminops/users");
  };
  return (
    <div className="user-wrapper">
      <div className="d-flex justify-content-between align-items-center">
        <div className="float-left">
          <h3>Edit User</h3>
        </div>
        <a className="float-right" onClick={() => navigate("../devops/adminops/users")}><i className="fa fa-arrow-circle-left mt-2 font20" aria-hidden="true"></i>Back</a>
      </div>
      <div className="row edituserroles">
        <div className="col-8">
          {loadingMaster ? (
            <Spinner>
              <i className="fa fa-spinner" aria-hidden="true"></i>
            </Spinner>
          ) : (
            <form>
              <div className="form-group row">
                <label className="control-label col-3 col-form-label">
                  User Id
                </label>
                <div className="col-7">
                  <input
                    id="userId"
                    type="text"
                    name="USERID"
                    value={editUserData.USERID}
                    className="form-control"
                    readOnly
                  />
                </div>
              </div>
              <div className="form-group row">
                <label className="control-label col-3 col-form-label">
                  First Name
                </label>
                <div className="col-7">
                  <input
                    id="firstName"
                    type="text"
                    name="FIRST_NAME"
                    value={editUserData.FIRST_NAME}
                    className="form-control"
                    onChange={handleInputChange}
                  />
                </div>
              </div>
              <div className="form-group row">
                <label className="control-label col-3 col-form-label">
                  Last Name
                </label>
                <div className="col-7">
                  <input
                    id="lastName"
                    type="text"
                    name="LAST_NAME"
                    value={editUserData.LAST_NAME}
                    className="form-control"
                    onChange={handleInputChange}
                  />
                </div>
              </div>
              <div className="form-group row">
                <label className="control-label col-3 col-form-label">
                  Group Name
                </label>
                <div className="col-7">
                  <select
                    id="groupName"
                    type="text"
                    name="GROUP_NAME"
                    value={editUserData.GROUP_NAME}
                    className="form-control"
                    onChange={handleInputChange}
                  >
                    {Groupname.map((group) => (
                      <option key={group} value={group}>
                        {group}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="form-group row">
                <label className="control-label col-3 col-form-label">
                  Role
                </label>
                <div className="col-7">
                  <select
                    id="role"
                    type="text"
                    name="ROLE_NAME"
                    value={editUserData.ROLE_NAME}
                    className="form-control"
                    onChange={handleInputChange}
                  >
                    {Role.map((group) => (
                      <option key={group} value={group}>
                        {group}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="form-group row">
                <label className="control-label col-3 col-form-label">
                  Group Member
                </label>
                <div className="col-7">
                  <select
                    id="groupMember"
                    type="text"
                    name="ACCESS_TYPE"
                    value={editUserData.ACCESS_TYPE}
                    className="form-control"
                    onChange={handleInputChange}
                  >
                    {Accesstype.map((access) => (
                      <option key={access} value={access}>
                        {access}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <br></br>
              <div className="form-group row col-12 justify-content-center">
                <input
                  type="submit"
                  value="Save"
                  onClick={updateUser}
                  className="btn btn-primary w-25"
                />
              </div>
            </form>
          )}
        </div>

        <ModalBox
          modalShow={show}
          handleClose={closeModal}
          modalData={parentModalData}
        >
          <a
            href="#"
            className="btn btn-success"
            data-dismiss="modal"
            onClick={() => closeModal()}
          >
            OK
          </a>
        </ModalBox>
      </div>
    </div>
  );
}
