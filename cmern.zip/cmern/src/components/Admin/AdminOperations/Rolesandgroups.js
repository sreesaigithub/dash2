import React, { useState, useEffect } from "react";
import axios from "axios";
import "datatables.net-dt/js/dataTables.dataTables";
import "datatables.net-dt/css/jquery.dataTables.min.css";
import $ from "jquery";
//jQuery libraries
import "jquery/dist/jquery.min.js";
import { useNavigate } from "react-router-dom";
import Spinner from "../../Dashboard/ExecutiveDashboard/Overview/spinner";

export default function Rolesandgroups() {
  const [activeTab, setActiveTab] = useState("roles");
  const [rolesData, setRolesData] = useState([]);
  const [groupsData, setGroupsData] = useState([]);
  const [loadingMaster, setLoadingMaster] = useState(false);

  let tableReInitialize = true;
  let myRoletable;
  let myGrouptable;
  let navigate = useNavigate();
  //const baseUrl = process.env.REACT_APP_BASE_API_URL;
  const baseUrl = window.__RUNTIME_CONFIG__.REACT_APP_BASE_API_USER_MGNT_URL;
  //const baseUrl ="http://localhost:8080/cocwp/api";
  const activeTabRG = (id) => {
    setActiveTab(id);
  };

  useEffect(() => {
    if (activeTab === "roles") {
      rolesGrid();
    }
    if (activeTab === "groups") {
      groupsGrid();
    }
  }, [activeTab]);

  const rolesGrid = () => {
    setLoadingMaster(true);
    axios.get(`${baseUrl}/admin/userRoles`).then((res) => {
      setRolesData(res.data);
      $("#rolesTable").DataTable().destroy();
      if (tableReInitialize) {
        tableReInitialize = false;
        setTimeout(function () {
          myRoletable = $("#rolesTable").DataTable({
            paging: true,
            sort: false,
            searching: true,
          });
        }, 1000);
        setLoadingMaster(false);
      }
    });
  };

  const groupsGrid = () => {
    setLoadingMaster(true);
    axios.get(`${baseUrl}/admin/userGroups`).then((res) => {
      setGroupsData(res.data);
      $("#groupTable").DataTable().destroy();
      if (tableReInitialize) {
        tableReInitialize = false;
        setTimeout(function () {
          myGrouptable = $("#groupTable").DataTable({
            paging: true,
            sort: false,
            searching: true,
          });
        }, 1000);
        setLoadingMaster(false);
      }
    });
  };

  const EditFunctionality = (id) => {
    navigate("../devops/adminops/rolesgroups/editgroup", { state: { id: id } });
  };

  const DeleteFunctionality = (id) => {
    axios
      .delete(`${baseUrl}/admin/${id}`)
      .then((res) => window.location.reload());
  };
  return (
    <div className="user-wrapper">
      <div>
        <div className="float-left">
          <h3>Roles & Groups</h3>
        </div>
      </div>
      <div className="clear">
        <div className="float-left multi-tabs">
          <ul className="nav nav-tabs border-0">
            <li className="nav-item">
              <a
                className={`nav-link ${
                  activeTab === "roles" ? "active show" : ""
                }`}
                data-toggle="pill"
                id="roles"
                href="#Roles"
                onClick={() => activeTabRG("roles")}
              >
                Roles
              </a>
            </li>
            <li className="nav-item">
              <a
                className={`nav-link ${
                  activeTab === "groups" ? "active show" : ""
                }`}
                data-toggle="pill"
                id="groups"
                href="#Groups"
                onClick={() => activeTabRG("groups")}
              >
                Groups
              </a>
            </li>
          </ul>
        </div>
      </div>
      {loadingMaster ? (
        <Spinner>
          <i className="fa fa-spinner" aria-hidden="true"></i>
        </Spinner>
      ) : (
        <div className="tab-content users-table clear">
          {/* <Spinner>{loadingMaster}</Spinner> */}

          <div
            id="Roles"
            className={`tab-pane ${
              activeTab === "roles" ? "active in show" : ""
            }`}
          >
            <br />

            <table id="rolesTable" className="table table-wrapper glb-table">
              <thead>
                <tr className="text-center">
                  <th>ROLE_ID</th>
                  <th>ROLE_NAME</th>
                  {/* <th>

                    </th> */}
                </tr>
              </thead>
              <tbody>
                {rolesData.length > 0 &&
                  rolesData.map((dt) => {
                    return (
                      <tr key={dt.ROLE_ID}>
                        <td>{dt.ROLE_ID}</td>
                        <td>{dt.ROLE_NAME}</td>
                        {/* <td><i className="fa fa-pencil" title="Edit"></i></td> */}
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
          <div
            id="Groups"
            className={`tab-pane ${
              activeTab === "groups" ? "active in show" : ""
            }`}
          >
            <br />

            <table id="groupTable" className="table table-wrapper glb-table">
              <thead>
                <tr className="text-center">
                  <th>Group Id</th>
                  <th>Group Name</th>
                  <th>Group Domains</th>
                  <th>Short Name</th>
                  <th className="w-50">Terms of Use</th>
                  <th>Active</th>
                  <th></th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {groupsData.length > 0 &&
                  groupsData.map((dt) => {
                    return (
                      <tr key={dt.GROUP_ID}>
                        <td>{dt.GROUP_ID}</td>
                        <td>{dt.GROUP_NAME}</td>
                        <td>{dt.GRP_DOMAINS}</td>
                        <td>{dt.SHORT_NAME}</td>
                        <td>{dt.TERMS_OF_USE}</td>
                        <td>
                          {dt.IS_ACTIVE === "Yes" ? (
                            <i
                              className="fa fa-check-circle green font16"
                              aria-hidden="true"
                            ></i>
                          ) : (
                            <i className="fa fa-times-circle dark-red font16"></i>
                          )}
                        </td>
                        <td>
                          <i
                            className="fa fa-pencil"
                            title="Edit"
                            onClick={() => EditFunctionality(dt.GROUP_ID)}
                          ></i>
                        </td>
                        <td>
                          <i
                            className="fa fa-trash"
                            title="Delete"
                            onClick={() => DeleteFunctionality(dt.GROUP_ID)}
                          ></i>
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
