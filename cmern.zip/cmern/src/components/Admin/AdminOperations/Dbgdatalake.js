﻿import React from 'react'

export default function Dbgdatalake() {
    return (
        <div>
            This is Dbgdatalake
        </div>
    )
}