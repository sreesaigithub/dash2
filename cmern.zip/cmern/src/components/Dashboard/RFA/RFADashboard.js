import React from "react";
import reporting from "../../../Images/AnalyticsReporting_icon.svg";
import commercial from "../../../Images/COC-Commercial.png";
import Medicaid from "../../../Images/COC-Medicaid.png";
import Medicare from "../../../Images/COC-Medicare.png";
import COCFGS from "../../../Images/COC-FGS.png";
import Excel from "../../../Images/COC-Excel.png";

import { useSelector } from "react-redux";

function RFADashboard() {
  const tierName = useSelector((state) => state.authReducer.tierName);
  const tierLevel = useSelector((state) => state.authReducer.tierLevel);

  return (
    <>
      <div
        className={`icon-wrapper RFADashboardWrapper ${
          tierName === "RFA" && tierLevel === 2 ? "d-flex" : "d-none"
        }`}
      >
        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Restated%20Financial%20Dashboards/Restated%20Financial%20Commercial%20Dashboard?rs:embed=true"
            target="_blank"
          >
            <img src={commercial} alt="RFA Commercial Icon" />
            <span>Commercial</span>
          </a>
        </div>

        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Restated%20Financial%20Dashboards/Restated%20Financial%20Medicaid%20Dashboard?rs:embed=true"
            target="_blank"
          >
            <img src={Medicaid} alt="RFA Medicaid Icon" />
            <span>Medicaid</span>
          </a>
        </div>

        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Restated%20Financial%20Dashboards/Restated%20Financial%20Medicare%20Dashboard?rs:embed=true"
            target="_blank"
          >
            <img src={Medicare} alt="RFA Medicare Icon" />
            <span>Medicare</span>
          </a>
        </div>

        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Restated%20Financial%20Dashboards/Restated%20Financial%20FGS%20Dashboard?rs:embed=true"
            target="_blank"
          >
            <img src={COCFGS} alt="RFA FGS Icon" />
            <span>FGS</span>
          </a>
        </div>

        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/browse/Restated%20Financial%20Dashboards/Restated%20Financial%20Pivot%20Table%20Consolidated%20Workbooks"
            target="_blank"
          >
            <img src={Excel} alt="RFA Excel Icon" />
            <span>Excel Pivot</span>
          </a>
        </div>
      </div>
    </>
  );
}

export default RFADashboard;
