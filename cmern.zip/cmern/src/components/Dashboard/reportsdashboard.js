import React from "react";

import reportbg from "../../Images/tech_v2.png";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { updateheadertext } from "../../redux/actions/authAction";
import financial from "../../Images/FInancials_icon.svg";
import reporting from "../../Images/AnalyticsReporting_icon.svg";
import dashboard from "../../Images/Dashboards_Icon.svg";
import { useSelector } from "react-redux";

function Reportsdashboard() {
  let navigate = useNavigate();
  const dispatch = useDispatch();
  const userData = useSelector((state) => state.authReducer.user);

  const handleDboardClick = (txt) => {
    navigate("/ExecutiveDashboard");
    dispatch(updateheadertext(txt));
  };

  const handlePowerboardClick = (txt) => {
    navigate("/powerbi");
    dispatch(updateheadertext(txt));
  };

  const svgStyles = {
    color: "#1559cd",
    height: "20px",
    marginLeft: "20px",
    marginRight: "20px",
    width: "20px",
    fill: "currentColor",
  };
  return (
    <>
      <div
        className="dboardLanding"
        style={{
          overflow: "auto",
          minHeight: "700px",
          backgroundColor: "#E3F4FD",
        }}
      >
        <div className="dboardParentSearchWrapper"
          style={{
            display: "flex",
            justifyContent: "end",
          }}
        >
          <div className="dboardParentSearchdiv">
            <div className="dboardSearch">
              <svg viewBox="0 0 32 32" className="searchiconsize" style={svgStyles} >
                <path d="M31.805 30.861l-12.012-12.012c1.781-2.003 2.873-4.631 2.873-7.516 0-6.249-5.084-11.333-11.333-11.333s-11.333 5.084-11.333 11.333c0 6.249 5.084 11.333 11.333 11.333 2.885 0 5.513-1.092 7.516-2.875l12.012 12.012c0.131 0.131 0.301 0.196 0.472 0.196s0.341-0.065 0.472-0.195c0.26-0.26 0.26-0.683 0-0.944zM1.333 11.333c0-5.513 4.485-10 10-10s10 4.487 10 10c0 5.515-4.485 10-10 10s-10-4.485-10-10z"></path>
              </svg>
              <input
                type="text"
                className="dboardinputSearch"
                placeholder="What are you looking for today?"
              />
            </div>
          </div>
        </div>

        <div className="d-content-box d-flex justify-content-center">
          <div className="wrapper costofcaredescription">
            <div className="caption">
              <h2>Cost of Care Platform</h2>
              <h6>
                Cost of Care Platform is a digitally enabled analytics platform
                to serve as a single source of truth for COC analytics across
                the enterprise. The COC Platform provides self service and
                interactive visualizations, insight-driven recommendations and
                effectiveness measurements of initiatives, capabilities include
                self service interactive dashboards, excel based pivots for
                ad-hoc analysis and deeper drill downs to member and claim line
                level insights.
              </h6>
            </div>

            <div className="icon-wrapper">
              <div
                className={`icon ${userData.isAuthorized != 1 ? "disabled" : ""
                  }`}
              >
                <a
                  onClick={() =>
                    handleDboardClick("Restated Financial Analytics")
                  }
                >
                  <img className="costofcareicon" src={financial} alt="Financial Icon" />
                  <span className="costofcareiconspan">
                    Restated Financial
                    <br />
                    Analytics
                  </span>
                </a>
              </div>
              <div
                className={`icon ${userData.isAuthorized != 1 || userData.roleId == 1
                    ? "disabled"
                    : ""
                  }`}
              >
                <a onClick={() => handlePowerboardClick("Power BI Reports")}>
                  <img className="costofcareicon" src={reporting} alt="Analytics and Reporting Icon" />
                  <span className="costofcareiconspan">
                    Power bi
                    <br />
                    Reports
                  </span>
                </a>
              </div>
              <div
                className={`icon ${userData.isAuthorized != 1
                    // || userData.roleId == 1 ||
                    // userData.roleId == 6
                    ? "disabled"
                    : ""
                  }`}
              >
                <a to="/impacttracking" href="/cocwp/impacttracking">
                  <img className="costofcareicon" src={dashboard} alt="Dashboard Icon" />
                  <span className="costofcareiconspan">
                    Impact Tracking <br />
                    Dashboard
                    <br />{" "}
                  </span>
                </a>
              </div>
            </div>
          </div>
          <div className="reference-wrapper">
            <a className="referencInfoLink" href="#">
              <div className="referenceLinkInnerParent">
                <span>How To . . .</span>
              </div>
            </a>
            <a className="referencInfoLink" href="#">
              <div className="referenceLinkInnerParent">
                <span>DASHBOARD ACCESS</span>
              </div>
            </a>
            <a className="referencInfoLink" href="#">
              <div className="referenceLinkInnerParent">
                <span>POWER-BI REPORTS ACCESS</span>
              </div>
            </a>
            <a className="referencInfoLink" href="#">
              <div className="referenceLinkInnerParent">
                <span>TRAININGS</span>
              </div>
            </a>
            <a className="referencInfoLink" href="#">
              <div className="referenceLinkInnerParent">
                <span>. . .</span>
              </div>
            </a>
          </div>
        </div>

        <div className="d-flex flex-column">
          <div className="d-flex justify-content-between alldashboardhdr w-85">
            <h3 className="">Dashboards</h3>
            <a color="white" role="button" href="/" className="">
              <span className="">See all</span>
            </a>
          </div>
          <div className="overalldboards w-85">
            <div className="eachboard">
              <a
                className={`dboardImgLnk ${userData.isAuthorized != 1 ? "pointer-none" : ""
                  }`}
                onClick={() =>
                  handleDboardClick("Restated Financial Analytics")
                }
              >
                <img src={reportbg} alt="RFA icon" height="100" width="100" />
                <div className="ms-3">
                  <span>Restated Financial Analytics</span>
                  <span className="subcopy">
                    The cost of care Executive dashboard gives Anthem Plan
                    Presidents opportunities to view key cost of care metrics
                    and gain valuable insights about their lines of business.
                    The self-service application provides intuitive, easy to
                    understand visualizations and insights with a focus on
                    Revenue, Gross Margin and Members Months against budget
                    expectations.
                  </span>
                </div>
              </a>
            </div>
            <div className="eachboard">
              <a
                className={`dboardImgLnk ${userData.isAuthorized != 1 || userData.roleId == 1
                    ? "pointer-none"
                    : ""
                  }`}
                onClick={() => handlePowerboardClick("Power BI Reports")}
              >
                <img src={reportbg} alt="RFA icon" height="100" width="100" />
                <div className="ms-3">
                  <span>Power-Bi Dashboard</span>
                  <span className="subcopy">
                    subcontent copy for Power-Bi Dashboard
                  </span>
                </div>
              </a>
            </div>
            <div className="eachboard">
              <a
                to="/"
                className={`dboardImgLnk ${userData.isAuthorized != 1 ||
                    userData.roleId == 1 ||
                    userData.roleId == 6
                    ? "pointer-none"
                    : ""
                  }`}
              >
                <img src={reportbg} alt="RFA icon" height="100" width="100" />
                <div className="ms-3">
                  <span>Impact Tracking</span>
                  <span className="subcopy">
                    subcontent copy for Impact Tracking
                  </span>
                </div>
              </a>
            </div>
          </div>
        </div>

        <div
          style={{
            display: "none",
          }}
        >
          <div
            className=""
            style={{
              border: "1px solid rgb(106, 151, 223)",
              backgroundColor: "rgb(106, 151, 223)",
              borderRadius: "10px",
              height: "130px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              margin: "0 30px",
              textAlign: "center",
              padding: "10px",
              cursor: "pointer",
              width: "237px",
              fontSize: "24px",
              color: "#ffffff",
            }}
            onClick={() => handleDboardClick("Restated Financial Analytics")}
          >
            Restated Financial Analytics
          </div>
          <div
            className=""
            style={{
              border: "1px solid rgb(106, 151, 223)",
              backgroundColor: "rgb(106, 151, 223)",
              borderRadius: "10px",
              height: "130px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              margin: "0 30px",
              textAlign: "center",
              padding: "10px",
              cursor: "pointer",
              width: "237px",
              fontSize: "24px",
              color: "#ffffff",
            }}
            onClick={() => handlePowerboardClick("Power BI Reports")}
          >
            Power BI Reports
          </div>
          <div
            className=""
            style={{
              border: "1px solid #E3F4FD",
              backgroundColor: "#E3F4FD",
              borderRadius: "10px",
              height: "130px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              margin: "0 30px",
              textAlign: "center",
              padding: "10px",
              cursor: "pointer",
              width: "237px",
              fontSize: "24px",
              color: "#231E33",
              opacity: "0.6",
            }}
          >
            Cost of Care
          </div>
        </div>
      </div>
    </>
  );
}

export default Reportsdashboard;
