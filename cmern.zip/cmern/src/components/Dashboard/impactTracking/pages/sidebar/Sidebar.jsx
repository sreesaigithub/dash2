import "./sidebar.css";
import "./MonthPickerStyle.css";
import React, { useEffect, useRef, useState } from 'react';
import { useDispatch, useSelector } from "react-redux";
import 'react-date-range/dist/styles.css';
import 'react-date-range/dist/theme/default.css';
import Select from 'react-select';
import { OverlayTrigger, Tooltip } from 'react-bootstrap';
import KeyboardDoubleArrowLeftIcon from '@mui/icons-material/KeyboardDoubleArrowLeft';
import KeyboardDoubleArrowRightIcon from '@mui/icons-material/KeyboardDoubleArrowRight';
import { getImpactStage1Run, stageFilterReset, stageFilterUpdate, getValuesFilter } from './../../../../../redux/actions/ImpackTrackingAction';
import { showLoadingView } from "../../../../../helper/util";
import moment from "moment";
import Picker from 'react-month-picker';
import Button from '@mui/material/Button';

const Sidebar = () => {
  const dispatch = useDispatch();
  const [filterOpen, setFilterToggle] = useState([false]);
  const stageFilterData = useSelector((state) => state.impactReducer.stageFilter);
  const valuesFilterVolMemberData = useSelector((state) => state.impactReducer.valuesFilter);
  const valuesFilterData = valuesFilterVolMemberData.filters;
  const loading = useSelector((state) => state.authReducer.loading);

  const [rangeValue, setRangeValue] = useState({ from: { year: 0, month: 0 }, to: { year: 0, month: 0 } });
  const pickRange = useRef();
  const pickerLang = {
    months: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    from:'From', to: "To"
  }

  function logChange(e) {
    stageFilterData[e.target.id] = e.target.value;
    dispatch(stageFilterUpdate(stageFilterData));
    dispatch(getValuesFilter('fetchValuesFilterData', stageFilterData));
  }

  function handleChange(e) {
    if (e.length > 0) {
      stageFilterData['sub_lob'] = (e.map(list => { return list.value })).join(',');
    } else {
      stageFilterData['sub_lob'] = valuesFilterData.sub_lob[0];
    }
    let v = stageFilterData['sub_lob'];
    let valuesArr = v.split(',')
    let valuesArrObj = []
    valuesArr.forEach((val) => { if (val !== "All") {
      valuesArrObj.push({
        value: val,
        label: val
      }) }
    })
    setSubLobList(valuesArrObj);
    dispatch(stageFilterUpdate(stageFilterData));
    dispatch(getValuesFilter('fetchValuesFilterData', stageFilterData));
  }

  function logChangeFollowUp(e) {
    stageFilterData[e.target.id] = Number(e.target.value);
    dispatch(stageFilterUpdate(stageFilterData));
    dispatch(getValuesFilter('fetchValuesFilterData', stageFilterData));
  }

  let subLob = valuesFilterData.sub_lob.map((list) => ({ value: list, label: list }));
  const [subLobList, setSubLobList] = useState([]);
  const [open, setOpen] = useState(false)
  const refOne = useRef(null)

  useEffect(() => {
    if ( !pickRange.current ) {
      return;
    }
    if(open) {
      pickRange.current.show();
    } else {
      pickRange.current.dismiss();
    }
  }, [open]);

  useEffect(() => {
    document.addEventListener("keydown", hideOnEscape, true)
    document.addEventListener("click", hideOnClickOutside, true)
  }, [])
 
  useEffect(() => {
    dispatch(getValuesFilter('fetchValuesFilterData', {}));
  }, [])

  const onResetSelect = () => {
    setSubLobList(null);
    dispatch(stageFilterReset())
    dispatch(getValuesFilter('fetchValuesFilterData', {}))
  }

  const hideOnEscape = (e) => {
    if (e.key === "Escape") {
      setOpen(false)
    }
  }

  const toggleMenu = () => {
    setFilterToggle(!filterOpen);
  }

  const runStage1 = () => {
    dispatch(getImpactStage1Run('fetchGroupName', stageFilterData));
  }

  const hideOnClickOutside = (e) => {
    if (refOne.current && !refOne.current.contains(e.target)) {
      setOpen(false)
    }
  }

  const { cohort_period_start = '', cohort_period_end = '' } = valuesFilterData;
  const startDate = moment(cohort_period_start, "YYYYMM");
  const endDate = moment(cohort_period_end, "YYYYMM");
  const stageFilterStart = moment(stageFilterData.cohort_period_start, "YYYYMM");
  const stageFilterEnd = moment(stageFilterData.cohort_period_end, "YYYYMM");

  rangeValue.from.year = stageFilterStart.year();
  rangeValue.from.month = stageFilterStart.month() + 1;
  rangeValue.to.year = stageFilterEnd.year();
  rangeValue.to.month = stageFilterEnd.month() + 1;

  const maxRanges = {
    min: { year: startDate.year(), month: startDate.month() + 1 },
    max: { year: endDate.year(), month: endDate.month() + 1 },
  }

  const handleRangeDissmis = (value) => {
    const { from, to } = value;
    stageFilterData['cohort_period_start'] = Number(`${from.year}${from.month < 10 ? "0" + from.month : from.month}`);
    stageFilterData['cohort_period_end'] = Number(`${to.year}${to.month < 10 ? "0" + to.month : to.month}`);
    dispatch(stageFilterUpdate(stageFilterData));
    dispatch(getValuesFilter('fetchValuesFilterData', stageFilterData));
    setRangeValue(value);
  }

  const monthPickerView = (open ? <Picker
  show={open}
  ref={pickRange}
  years={maxRanges}
  value={rangeValue}
  lang={pickerLang}
  onDismiss={(value) => handleRangeDissmis(value)} /> : null);

  return (
    <div className={`sidebar ${filterOpen ? 'is-open' : ''}`}>
      {showLoadingView(loading)}
      <div className="sidebarcenter">
        <ul>
          <div className="sidebarTitleDiv">
            <div class="sidebartitle">FILTER POPULATION</div>
            <div className={`filterToggleMenu ${!filterOpen ? 'is-open' : ''}`}>
              <OverlayTrigger
                placement="auto"
                delay={{ show: 250, hide: 400 }}
                overlay={(props) => (
                  <Tooltip id="button-tooltip" {...props}>
                    {filterOpen ? "Hide Filter" : "Show Filter"}
                  </Tooltip>
                )}
              >
                {filterOpen ? <KeyboardDoubleArrowLeftIcon onClick={toggleMenu} /> : <KeyboardDoubleArrowRightIcon onClick={toggleMenu} />}
              </OverlayTrigger>
            </div>
          </div>
          <form>
            <li className="sidebarfieldname">
              <span>Program Name</span>
            </li>
            <select className="form-field-name1" value={stageFilterData.program_name} id="program_name" onChange={(e) => logChange(e)} defaultValue={stageFilterData.program_name}>
              {valuesFilterData.program_name.map((list) => <option value={list}>{list}</option>)}
            </select>
            <li className="sidebarfieldname">
              <span>Line of Business</span>
            </li>
            <select className="form-field-name1" value={stageFilterData.lob} id="lob" onChange={(e) => logChange(e)} defaultValue={stageFilterData.lob}>
              {valuesFilterData.lob.map((list) => <option value={list}>{list}</option>)}
            </select>
            <li className="sidebarfieldname">
              <span>Sub LOB</span>
            </li>
            <Select className="form-field-name2" value={subLobList} options={subLob} isMulti={true} onChange={(e) => handleChange(e)} placeholder={valuesFilterData.sub_lob[0]} />
            <li className="sidebarfieldname">
              <span>Funding Type</span>
            </li>
            <select className="form-field-name1" value={stageFilterData.funding_type} id="funding_type" onChange={(e) => logChange(e)} defaultValue={stageFilterData.funding_type}>
              {valuesFilterData.funding_type.map((list) => <option value={list}>{list}</option>)}
            </select>
            <li className="sidebarfieldname">
              <span>Region</span>
            </li>
            <select className="form-field-name1" value={stageFilterData.region} id="region" onChange={(e) => logChange(e)} defaultValue={stageFilterData.region}>
              {valuesFilterData.region.map((list) => <option value={list}>{list}</option>)}
            </select>

            <li className="sidebarfieldname">
              <span>Follow Up Period</span>
            </li>
            <select className="form-field-name1" value={stageFilterData.follow_up_period} id="follow_up_period" onChange={(e) => logChangeFollowUp(e)} defaultValue={stageFilterData.follow_up_period}>
              <option value="3">3 months</option>
              <option value="6">6 months</option>
              <option value="9">9 months</option>
              <option value="12">12 months</option>
            </select>

            <li className="sidebarfieldname">
              <span>Case ID Period </span>
            </li>
            <div className="calendarWrap">
              <input
                value={`${stageFilterStart.format('MMM YYYY')} - ${stageFilterEnd.format('MMM YYYY')}`}
                readOnly
                className="inputBox"
                onClick={() => {
                  setOpen(open => !open);
                }}
              />

              <div ref={refOne} className="monthPickerFilter">
                {monthPickerView}
              </div>
            </div>
            <li className="sidebarfieldname">
              <span>Amount Type</span>
            </li>
            <select className="form-field-name1" value={stageFilterData.amount_type} id="amount_type" onChange={(e) => logChange(e)} defaultValue={stageFilterData.amount_type}>
              <option value="PAID">Paid Amount</option>
              <option value="ALWD">Allowed Amount</option>
            </select>

            <div className="sidebarbottom">
              <div style={{ flex: 1 }} >
                <Button style={{ width: '100%', fontSize: 12, textTransform: 'capitalize' }} className="resetOption" variant="outlined" onClick={onResetSelect}>Reset</Button>
              </div>
              <div className="colorOptiondiv" style={{ flex: 1 }}>
                <Button variant="contained" style={{ fontSize: 12, textTransform: 'capitalize' }} onClick={runStage1} className="colorOption" >Run Stage 1</Button>
              </div>
            </div>
          </form>
        </ul>
      </div>
    </div>
  );
};

export default Sidebar;
