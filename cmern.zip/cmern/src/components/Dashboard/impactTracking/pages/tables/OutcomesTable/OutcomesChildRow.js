import React, { useEffect, useState } from "react";
import OutcomesVariableRow from "./OutcomesVariableRow";
import RemoveOutlinedIcon from '@mui/icons-material/RemoveOutlined';
import { IconButton } from '@mui/material';
import AddOutlinedIcon from '@mui/icons-material/AddOutlined';
import { TABLE_INTENT_SPACE } from "../../../../../../helper/constants";

export default function OutcomesChildRow(props) {
    const [childShow, setChildShow] = useState([]);
    const { childrenRows = [], hideRow = false, stageLevel, expandAll=false } = props;
    const stagePadding = TABLE_INTENT_SPACE * stageLevel;
    useEffect(() => {
        if (childrenRows && childrenRows.length !== 0) {
            const childShowFlag = Array(childrenRows.length).fill(expandAll || false);
            setChildShow(childShowFlag);
        }
    }, [childrenRows, expandAll]);
    const childRow = childrenRows.map((childrenRow, index) => {
        return [
            <tr keyField={`${childrenRow.name}_${index}`} className={`rowExpandStyle categoryStyle blueTextColorStyle ${!hideRow ? 'hideRow' : ''}`}>
                <td colSpan={17} style={{ paddingLeft: stagePadding }}>
                    <IconButton
                        size="small"
                        style={{ fontSize: 8 }}
                        onClick={(e) => {
                            const childFlag = [...childShow];
                            childFlag[index] = !childFlag[index];
                            setChildShow(childFlag);
                        }}
                    >
                        <div className="borderOutlineIcon">  {childShow[index] ? <RemoveOutlinedIcon fontSize="small" /> : <AddOutlinedIcon fontSize="small" />}</div>
                    </IconButton>
                    <span className="blueTextColorStyle">{childrenRow.name}</span>
                </td>
            </tr>,
            <OutcomesVariableRow hideRow={(childShow[index] && hideRow)} expandAll={expandAll} stageLevel={stageLevel} rows={childrenRow} />]
    })

    return childRow;
}