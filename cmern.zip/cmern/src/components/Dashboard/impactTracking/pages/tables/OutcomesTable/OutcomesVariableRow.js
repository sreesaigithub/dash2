import React from 'react';
import OutcomesChildRow from './OutcomesChildRow';
import AddOutlinedIcon from '@mui/icons-material/AddOutlined';
import { IconButton } from '@mui/material';
import TaskAltOutlinedIcon from '@mui/icons-material/TaskAltOutlined';
import { TABLE_INTENT_SPACE } from '../../../../../../helper/constants';
import { formatSignNumber } from '../../../../../../helper/util';

export default function OutcomesVariableRow(props) {
    const { rows = {}, hideRow = false, stageLevel = 0, expandAll = false } = props;
    const { variables } = rows;
    const leftStyle = 5 * stageLevel;

    const convertPercent = (value = '') => {
        if (!value) {
            return value === 0 ? '0%' : '';
        }
        let temp = new Intl.NumberFormat('us-IN', {
            style: 'percent',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0,
        }).format(value);

        return temp;
    }

    const variableRow = variables.map((row, index) => {
        let { measure_type, stat_significant, prior_control_mean, post_control_mean, prior_study_mean, post_study_mean, study_trend, control_trend, did, program_impact, confidence_low, confidence_high, display_name } = row;
        let pctType = false, signType = false;
        if (measure_type.toLowerCase() === 'pct') {
            pctType = true;
            signType = false
        } else if (measure_type.toUpperCase() === 'PMPM'
            || measure_type.toUpperCase() === 'AVG $/ADMIT'
            || measure_type.toUpperCase() === 'AVG $/DAY') {
            pctType = false;
            signType = true;
        }
        const statSign = stat_significant ? <TaskAltOutlinedIcon fontSize="small" sx={{ color: '#f59355', fontSize: 16 }} /> : null;
        return (
            <tr className={!hideRow ? 'hideRow' : ''} k>
                <td className='variableDisplayName' style={{ paddingLeft: leftStyle }}>
                    <IconButton
                        aria-label="expand row"
                        size="small"
                        style={{ fontSize: 8, visibility: 'hidden', marginRight: TABLE_INTENT_SPACE }}
                    >
                        <div className="borderOutlineIcon hideChildIcon"><AddOutlinedIcon fontSize="small" /></div>
                    </IconButton>
                    <div>{display_name}</div>
                </td>
                <td>{statSign}</td>
                <td style={{ textAlign: 'left', paddingLeft: 10 }}>{measure_type}</td>
                <td colSpan={3} style={{ padding: 0 }}>
                    <div className="outcomesVariableStyle">
                        <div className="outcomeVarField">{pctType ? convertPercent(prior_control_mean) : signType ? formatSignNumber(prior_control_mean) : prior_control_mean ? prior_control_mean.toLocaleString('en-US', { maximumFractionDigits: 2 }) : ''}</div>
                        <div className="outcomeVarField">{pctType ? convertPercent(post_control_mean) : signType ? formatSignNumber(post_control_mean) : post_control_mean ? post_control_mean.toLocaleString('en-US', { maximumFractionDigits: 2 }) : ''}</div>
                    </div>
                </td>
                <td colSpan={3}>
                    <div className="outcomesVariableStyle">
                        <div className="outcomeVarField">{pctType ? convertPercent(prior_study_mean) : signType ? formatSignNumber(prior_study_mean) : prior_study_mean ? prior_study_mean.toLocaleString('en-US', { maximumFractionDigits: 2 }) : ''}</div>
                        <div className="outcomeVarField">{pctType ? convertPercent(post_study_mean) : signType ? formatSignNumber(post_study_mean) : post_study_mean ? post_study_mean.toLocaleString('en-US', { maximumFractionDigits: 2 }) : ''}</div>
                    </div>
                </td>
                <td colSpan={3}>
                    <div className="outcomesVariableStyle">
                        <div className="outcomeVarField">{convertPercent(study_trend)}</div>
                        <div className="outcomeVarField">{convertPercent(control_trend)}</div>
                    </div>
                </td>
                <td className='outComeVarField outcomeDidStyle'>{pctType ? convertPercent(did) : signType ? formatSignNumber(did) : did ? did.toLocaleString('en-US', { maximumFractionDigits: 2 }) : ''}</td>
                <td className='outComeVarField'>{convertPercent(program_impact)}</td>
                <td colSpan={3}>
                    <div className="outcomesVariableStyle">
                        <div className="outcomeVarField">{pctType ? convertPercent(confidence_low) : signType ? formatSignNumber(confidence_low) : confidence_low ? confidence_low.toLocaleString('en-US', { maximumFractionDigits: 2 }) : ''}</div>
                        <div className="outcomeVarField">{pctType ? convertPercent(confidence_high) : signType ? formatSignNumber(confidence_high) : confidence_high ? confidence_high.toLocaleString('en-US', { maximumFractionDigits: 2 }) : ''}</div>
                    </div>
                </td>
            </tr>
        );
    });
    return [variableRow,
        <OutcomesChildRow hideRow={hideRow} expandAll={expandAll} stageLevel={stageLevel + 1} childrenRows={rows.children} />];
}