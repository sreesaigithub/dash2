import { IconButton } from '@mui/material';
import React, { useEffect, useState } from 'react';
import AddOutlinedIcon from '@mui/icons-material/AddOutlined';
import RemoveOutlinedIcon from '@mui/icons-material/RemoveOutlined';
import OutcomesVariableRow from './OutcomesVariableRow';

export default function OutcomesGroupRow(props) {
    const { rows, expandAll = false } = props;
    const [show, setShow] = useState([]);

    useEffect(() => {
        const showFlag = Array(rows.length).fill(expandAll || false);
        setShow(showFlag)
    }, [rows, expandAll]);

    const outcomeRows = rows.map((row, index) => {
        const { name } = row;
        return [
            <tr keyField={`${name}_${index}`} className='rowExpandStyle blueTextColorStyle categoryStyle'>
                <td colSpan={17} style={{ marginLeft: 5, fontWeight: '500'}}>
                    <IconButton
                        size="small"
                        style={{ fontSize: 8 }}
                        onClick={(e) => {
                            let showFlags = [...show];
                            showFlags[index] = !showFlags[index];
                            setShow(showFlags);
                        }}
                    >
                        <div className="borderOutlineIcon">  {show[index] ? <RemoveOutlinedIcon fontSize="small" /> : <AddOutlinedIcon fontSize="small" />}</div>
                    </IconButton>
                    <span className="blueTextColorStyle">{name}</span>
                </td>
            </tr>,
            <OutcomesVariableRow hideRow={show[index]} expandAll={expandAll} rows={row} />
        ];
    });
    return [outcomeRows];   
}