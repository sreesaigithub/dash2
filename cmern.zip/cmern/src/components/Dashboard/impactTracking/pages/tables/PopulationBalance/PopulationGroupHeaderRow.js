import React from 'react';
import AddOutlinedIcon from '@mui/icons-material/AddOutlined';
import RemoveOutlinedIcon from '@mui/icons-material/RemoveOutlined';
import { IconButton } from '@mui/material';
import { useState } from 'react';
import PopulationVariableRow from './PopulationVariableRow';
import { useEffect } from 'react';

export default function PopulationGroupHeaderRow(props) {
    const [show, setShow] = useState([]);
    const { rows, expandAll } = props;

    useEffect(() => {
        const showFlag = Array(rows.length).fill((expandAll || false));
        setShow(showFlag);
    }, [rows, expandAll]);

    const populateRow = rows.map((row, index) => {
        const { name } = row;
        return [
            <tr keyField={`${name}_${index}`} className='rowExpandStyle blueTextColorStyle categoryStyle'>
                <td colSpan={12} style={{ fontWeight: '500'}}>
                    <IconButton
                        size="small"
                        style={{ fontSize: 8 }}
                        onClick={(e) => {
                            let showFlags = [...show];
                            showFlags[index] = !showFlags[index];
                            setShow(showFlags);
                        }}
                    >
                        <div className="borderOutlineIcon">  {show[index] ? <RemoveOutlinedIcon fontSize="small" /> : <AddOutlinedIcon fontSize="small" />}</div>
                    </IconButton>
                    <span className='blueTextColorStyle'>{name}</span>
                </td>
            </tr>, <PopulationVariableRow expandAll={props.expandAll} hideRow={show[index]} row={row} />
        ];
    });
    return populateRow;
}