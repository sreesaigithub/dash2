import './ShowViewDetail.css';
import React, { useEffect, useState } from 'react';
import { Modal, Button } from 'react-bootstrap';
import ProgramImpactViewDetails from './ProgramImpactViewDetails';
import CloseIcon from '@mui/icons-material/Close';
import PopulationBalanceTable from './PopulationBalance/PopulationBalanceTable';
import TaskAltOutlinedIcon from '@mui/icons-material/TaskAltOutlined';
import ReportProblemOutlinedIcon from '@mui/icons-material/ReportProblemOutlined';
import Paralleltrendtable from './Paralleltrendtable';
import { showLoadingView } from '../../../../../helper/util';
import { useSelector } from 'react-redux';
import JobInfoHeader from './JobInfoHeader';

export default function ShowViewDetails(props) {
    const { show, onHide, showValue, populationErrorCode } = props;
    const ref = React.createRef();
    const [expandAll, setExpandAll] = useState(false);
    const [hideExpand, setHideExpand] = useState(true);
    const loading = useSelector((state) => state.authReducer.loading);

    useEffect(() => {
        if (show) {
            document.body.classList.add('showResultClass');
        } else {
            document.body.classList.remove('showResultClass');
        }
        return () => {
            document.body.classList.remove('showResultClass');
        };
    }, [show])

    const tabShowResult = [
        {
            title: 'Parallel Trends',
            content: <Paralleltrendtable />
        },
        {
            title: 'Population Balance',
            content: <PopulationBalanceTable expandAll={expandAll} />
        },
        {
            title: 'Program Impact',
            content: <ProgramImpactViewDetails hideExpand={(hideFlag) => {
                setHideExpand(hideFlag)}} expandAll={expandAll} />
        }
    ]

    let populationStatusIcon = null;

    if (showValue === 1) {
        populationStatusIcon = populationErrorCode && populationErrorCode.toUpperCase() === 'SMD_FAILURE' ? <ReportProblemOutlinedIcon fontSize="small" sx={{ marginBottom: '4px', color: '#ffca40' }} /> : <TaskAltOutlinedIcon className="completeStyle" fontSize="small" />;
    }

    const tabValue = tabShowResult[showValue];

    return (<Modal show={show} fullscreen onHide={() => onHide()}>
        <Modal.Body>
            <div>
                {showLoadingView(loading)}
                <div className='modalTitleStyle'>{tabValue.title}<span style={{ marginLeft: 5 }}>{populationStatusIcon}</span>
                    <div className='modalCloseStyle'>
                        {showValue !== 0 && hideExpand ? <Button style={{ marginRight: 5 }} onClick={() => setExpandAll((expandAll) => !expandAll)}>{expandAll ? 'Collapse All' : 'Expand All'}</Button> : null}
                        <Button onClick={() => {
                            onHide();
                            setExpandAll(false);
                        }}><CloseIcon />Close</Button>
                    </div>
                </div>
                <JobInfoHeader headerClass='showResultwidget' />
                <div className='modalContentStyle' ref={ref}>
                    {tabValue.content}
                </div>
            </div>
        </Modal.Body>
    </Modal>);
}