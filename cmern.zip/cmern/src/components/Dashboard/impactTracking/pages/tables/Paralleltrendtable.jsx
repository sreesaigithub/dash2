import "./paralleltrendtable.css";
import React, { useEffect } from "react";
import { makeStyles } from '@material-ui/core/styles';
import { useSelector, useDispatch } from "react-redux";
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper } from "@mui/material";
import { getParallelMetricData } from "../../../../../redux/actions/ImpackTrackingAction";

const useStyles = makeStyles({
  customTable: {
    "& .MuiTableCell-sizeSmall": {
      padding: "3px"
    },
    "& .MuiTableContainer-root": {
      "box-shadow": "none",
    },

    "&.MuiTable-root .MuiTableRow-head": {
      "border-top": "1px solid black",
      "border-bottom": "1px solid black",
    },
  },
});

export default function Paralleltrendtable() {
  const parallelMetric = useSelector((state) => state.impactReducer.parallelMetricData);
  const stage1Data = useSelector((state) => state.impactReducer.stage1RowDataSelected);
  const { analysis_job_id = '' } = stage1Data;
  const classes = useStyles();

  const dispatch = useDispatch();
  const valueFormat = (value) => value.toLocaleString('en-US', { maximumFractionDigits: 3 });

  useEffect(() => {
    dispatch(getParallelMetricData(analysis_job_id));
  }, [analysis_job_id, dispatch]);

  return (
    <TableContainer component={Paper}>
      <Table aria-label="simple table" classes={{ root: classes.customTable }} size="small" padding="none">
        <TableHead  sx={{ fontSize: "11px", borderBottom: '0px'}}>
          <TableRow>
            <TableCell align="center" sx={{ backgroundColor: "rgb(242, 246, 247)", border: "2px solid white" }} colSpan="3">Matched-UnWeighted</TableCell>
            <TableCell align="center" sx={{ backgroundColor: "rgb(242, 246, 247)", border: "2px solid white" }} colSpan="3">Matched-Weighted</TableCell>
          </TableRow>
          <TableRow>
            <TableCell align="center" sx={{ backgroundColor: "rgb(242, 246, 247)", border: "2px solid white" }}>Months</TableCell>
            <TableCell align="center" sx={{ backgroundColor: "rgb(242, 246, 247)", border: "2px solid white" }}>Control</TableCell>
            <TableCell align="center" sx={{ backgroundColor: "rgb(242, 246, 247)", border: "2px solid white" }}>Study</TableCell>
            <TableCell align="center" sx={{ backgroundColor: "rgb(242, 246, 247)", border: "2px solid white" }}>Months</TableCell>
            <TableCell align="center" sx={{ backgroundColor: "rgb(242, 246, 247)", border: "2px solid white" }}>Control</TableCell>
            <TableCell align="center" sx={{ backgroundColor: "rgb(242, 246, 247)", border: "2px solid white" }}>Study</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {parallelMetric.length !== 0 ?
            parallelMetric.map((row) => (
              <TableRow  sx={{ fontSize: "11px", borderBottom: '0px', '&:last-child td, &:last-child th': { border: 0 }}}>
                <TableCell align="center">{row.month}</TableCell>
                <TableCell align="center">{valueFormat(row.unweighted_control)}</TableCell>
                <TableCell align="center">{valueFormat(row.unweighted_study)}</TableCell>
                <TableCell align="center">{row.month}</TableCell>
                <TableCell align="center">{valueFormat(row.weighted_control)}</TableCell>
                <TableCell align="center">{valueFormat(row.weighted_study)}</TableCell>
              </TableRow>
            ))
            :
            <TableRow>
              <TableCell align="center" colSpan="5">There are no Parallel Trend Data for this Job</TableCell>
            </TableRow>
          }
        </TableBody>
      </Table>
    </TableContainer>
  );
}