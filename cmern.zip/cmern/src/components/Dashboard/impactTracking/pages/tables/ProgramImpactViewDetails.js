import React, { useEffect, useState } from 'react';
import OutcomesMainTable from './OutcomesTable/OutcomesMainTable';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import { Tab } from '@mui/material';
import BarGraph from '../chart/MetricsSummaryBarGraph';
import { useDispatch, useSelector } from 'react-redux';
import { parseJobsDate } from '../../../../../helper/util';
import { matrixSummaryData } from '../../../../../redux/actions/ImpackTrackingAction';

export default function ProgramImpactViewDetails({expandAll = false, hideExpand}) {

  const [tabValue, setTabValue] = useState('1');
  const stage1Data = useSelector((state) => state.impactReducer.stage1RowDataSelected);
  const { analysis_job_id = '',criteria = {}, study_group_member_count = 0 } = stage1Data;
  const dispatch = useDispatch();

  useEffect(() => {
    hideExpand(tabValue === '2');

    return (() => {
      hideExpand(true);
    })
  }, [hideExpand, tabValue]);

  useEffect(() => {
    dispatch(matrixSummaryData(analysis_job_id));
  }, [dispatch, analysis_job_id]);

  return (
    <div>
      <div className="countContainerStyle">
        <div className="countDivStyle" style={{marginRight: 10}}>
          <div className="countNumber">{study_group_member_count.toLocaleString('en-US', {maximumFractionDigits:2})}</div>
          <div className='countTextStyle'>Study Group Members</div>
        </div>
        <div className="countDivStyle">
          <div className="countNumber">{parseJobsDate(criteria.cohort_period_start)} - {parseJobsDate(criteria.cohort_period_end)}</div>
          <div className='countTextStyle'>Members Identified</div>
        </div>
      </div>
      <TabContext value={tabValue} >
        <TabList onChange={(event, newValue) => {
          hideExpand(newValue === '2');
          setTabValue(newValue);
        }} aria-label="lab API tabs example">
          <Tab sx={{ textTransform: 'capitalize' }} label="Key Metrics Summary" value="1" />
          <Tab sx={{ textTransform: 'capitalize' }} label="Outcomes" value="2" />
        </TabList>

        <TabPanel sx={{ padding: '5px 5px 5px 0px' }} value="1">
          <div style={{width: "1000px"}}><BarGraph data={useSelector((state) => state.impactReducer.matrixSummaryData)} /></div>
          
        </TabPanel>
        <TabPanel sx={{ padding: '5px 5px 5px 0px' }} value="2">
          <div className="modalContainerStyle"><OutcomesMainTable expandAll={expandAll} /></div>
        </TabPanel>
      </TabContext>
    </div>
  );
}