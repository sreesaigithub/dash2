import "./populationbalancetable.css";
import "../../grids/Populationbalance.css";
import * as React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { populationBalanceMetricsData } from '../../../../../../redux/actions/ImpackTrackingAction';
import { useEffect } from 'react';
import { Row, Table } from 'react-bootstrap';
import PopulationGroupHeaderRow from './PopulationGroupHeaderRow';
import { parseJobsDate } from "../../../../../../helper/util";

export default function PopulationBalanceTable(props) {
    const rows = useSelector((state) => state.impactReducer.populationBalanceTableData);
    const stage1Data = useSelector((state) => state.impactReducer.stage1RowDataSelected);
    const { analysis_job_id = '', criteria = {}, study_group_member_count = 0, control_group_member_count = 0 } = stage1Data;

    const dispatch = useDispatch();
    const headerStyle = { paddingRight: 0, backgroundColor: "white", borderBottom: "2px solid lightgrey" };

    useEffect(() => {
        dispatch(populationBalanceMetricsData(analysis_job_id));
    }, [analysis_job_id, dispatch]);

    return (
        <div>
            <div className="tableCountStyle">
                <div className="tableCountDiv">
                    Control Group Members : <span className="blueTextColorStyle">{control_group_member_count.toLocaleString('en-US', {maximumFractionDigits:2})}</span>
                </div>
                <div className="tableCountDiv">
                    Study Group Members: <span className="blueTextColorStyle">{study_group_member_count.toLocaleString('en-US', {maximumFractionDigits:2})}</span>
                </div>
                <div className="tableCountDiv">
                    Members Identified From : 
                    <span className="blueTextColorStyle">
                        {parseJobsDate(criteria.cohort_period_start)} - {parseJobsDate(criteria.cohort_period_end)}
                    </span>
                </div>
            </div>
            <Table className="populationTableStyle">
                <thead className="stickyHeader">
                    <th style={{ width: "20%", ...headerStyle }}>
                        <Row style={{ padding: 0 }}>
                            <div className="groupBorder">&nbsp;</div>
                            <div className="populationGroup">
                                <div className="popluationChild" style={{ textAlign: 'left', paddingLeft: 10 }}>Category</div>
                            </div>
                        </Row>
                    </th>
                    <th align="left" style={headerStyle}>
                        <Row style={{ padding: 0 }}>
                            <div className="groupBorder">&nbsp;</div>
                            <div className="populationGroup" style={{ padding: 0 }}>
                                <div className="popluationChild">Type</div>
                            </div>
                        </Row>
                    </th>
                    <th align="center" style={headerStyle} colSpan="3">
                        <Row style={{ padding: 0 }}>
                            <div className="groupBorder">Baseline Unadjusted</div>
                            <div className="populationGroup">
                                <div className="cellBorder popluationChild">Control</div>
                                <div className="cellBorder popluationChild" style={{ marginLeft: 0 }}>Study</div>
                                <div className="popluationChild" style={{ marginLeft: 0 }}>Std Diff</div>
                            </div>
                        </Row>
                    </th>
                    <th align="center" style={headerStyle} colSpan="3">
                        <Row style={{ padding: 0 }}>
                            <div className="groupBorder">Baseline Adjusted (Weighted)</div>
                            <div className="populationGroup">
                                <div className="cellBorder popluationChild">Control</div>
                                <div className="cellBorder popluationChild" style={{ marginLeft: 0 }}>Study</div>
                                <div className="popluationChild" style={{ marginLeft: 0 }}>Std Diff</div>
                            </div>
                        </Row>
                    </th>
                    <th align="center" style={headerStyle} colSpan="2">
                        <Row style={{ padding: 0, marginRight: 0 }}>
                            <div className="groupBorder">Median</div>
                            <div className="populationGroup">
                                <div className="cellBorder popluationChild">Control</div>
                                <div className="popluationChild">Study</div>
                            </div>
                        </Row>
                    </th>
                    <th align="center" style={headerStyle} colSpan="2">
                        <Row style={{ padding: 0 }}>
                            <div className="groupBorder">Std Dev</div>
                            <div className="populationGroup">
                                <div className="cellBorder popluationChild">Control</div>
                                <div className="popluationChild">Study</div>
                            </div>
                        </Row>
                    </th>
                </thead>
                <tbody>
                    <PopulationGroupHeaderRow expandAll={props.expandAll} rows={rows} />
                </tbody>
            </Table>
        </div>
    );
}