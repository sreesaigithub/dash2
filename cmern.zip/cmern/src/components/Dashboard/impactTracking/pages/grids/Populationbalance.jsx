import "./Populationbalance.css";
import TaskAltOutlinedIcon from '@mui/icons-material/TaskAltOutlined';
import ReportProblemOutlinedIcon from '@mui/icons-material/ReportProblemOutlined';
import { useSelector, useDispatch } from 'react-redux';
import { getSMDSummaryData } from '../../../../../redux/actions/ImpackTrackingAction';
import { useEffect } from 'react';

export default function Populationbalance() {

  const smdSummaryInfo = useSelector((state) => state.impactReducer.smdSummaryData);
  const stage1Data = useSelector((state) => state.impactReducer.stage1RowDataSelected);
  const smdSummaryList = smdSummaryInfo.smd_summary;

  const dispatch = useDispatch();

    useEffect(() => {
      dispatch(getSMDSummaryData(stage1Data.analysis_job_id));
    }, []);

  return (
    <div className="grids">
      <div className="gridsWrapper">
        {smdSummaryList && smdSummaryList.map(list =>  
        <div className={`block ${list.smd_error === true ? '' : 'statusAlert'}`}>
            <span className="subblock">{list.smd_category}</span>
            <div className="statussubicon">{ list.smd_error === true ?  <div className="icon2">  <ReportProblemOutlinedIcon/> </div> : <div className="icon1"> <TaskAltOutlinedIcon/> </div> }</div>
        </div> )} 
      </div>
    </div>
  )
}