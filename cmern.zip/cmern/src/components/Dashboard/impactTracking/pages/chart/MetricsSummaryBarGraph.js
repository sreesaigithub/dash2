import React from "react";
import { Bar } from 'react-chartjs-2';
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
} from 'chart.js';
import ChartDataLabels from "chartjs-plugin-datalabels";
import ChartAnnotation from "chartjs-plugin-annotation";
import { formatSignNumber } from "../../../../../helper/util";

ChartJS.register(
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    ChartDataLabels,
    ChartAnnotation,
);

function MetricsSummaryBarGraph(props) {
    const keyData = props.data;
    const maxValue = Math.max(...(keyData.map((o) => o.did)));
    const minValue = Math.min(...(keyData.map((o) => o.did)));
    const options = {
        indexAxis: 'y',
        scaleShowLabels: false,
        layout: {
            padding: {
                left: 30,
                right: 50,
                top: 30,
                bottom: 30,
            },
        },
        scales: {
            xAxis: {
                display: false,
                max: maxValue + 200,
                min: minValue < 0 ? minValue - 200 : 0,
                grid: {
                    drawBorder: false,
                    display: false,
                },
            },
            yAxis: {
                grid: {
                    display: false,
                },
                ticks: {
                    color: function(context) {
                        const { index } = context;
                        const data = keyData[index];
                        let color = null;
                        if (data.stat_significant) {
                            color = '#f59355';
                        }
                        return color;
                    },
                    callback: function (value, index, ticks) {
                        const data = keyData[index];
                        let tickSbl = '';
                        if(data.stat_significant) {
                            tickSbl = '✓';
                        }
                        return `${tickSbl} ${this.getLabelForValue(value)}`;
                    }
                }
            },
        },
        responsive: true,
        plugins: {
            tooltip: {
                enabled: false,
            },
            legend: {
                display: false,
            },
            title: {
                display: true,
                align: 'start',
                text: 'DiD and Percent Program Impact on Cost PMPM',
                font: {
                    weight: "bold",
                    size:"14px"
                },
            },
            annotation: {
                annotations: [{
                    drawTime: 'afterDatasetsDraw',
                    borderColor: '#E9E9E9',
                    borderWidth: 1,
                    mode: 'vertical',
                    type: 'line',
                    value: 0,
                    scaleID: 'xAxis',
                }]
            },
        },
    };

    const data = {
        labels: keyData.map((o) => o.display_name),
        datasets: [
            {
                label: '',
                data: keyData.map((o) => o.did),
                barThickness: 8,
                maxBarLength: -1,
                borderColor: keyData.map((o) => o.did < 0 ? "#00bbba" : "#815e90"),
                backgroundColor: keyData.map((o) => o.did < 0 ? "#00bbba" : "#815e90"),
                datalabels: {
                    color: keyData.map((o) => o.did < 0 ? "#00bbba" : "#815e90"),
                    anchor: keyData.map((o) => o.did < 0 ? "start" : "end"),
                    align: keyData.map((o) => o.did < 0 ? "start" : "end"),
                    formatter: function (value, context) {
                        return `${formatSignNumber(value, 0)} (${Math.round((keyData[context.dataIndex].program_impact) * 100)}%)`;
                    },
                },
            },
        ],
    };

    return <Bar options={options} data={data} />;
}

export default MetricsSummaryBarGraph; 