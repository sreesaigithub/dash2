import "./chart.css";
import React, { useEffect } from "react";
import { VictoryAxis, VictoryChart, VictoryLine, VictoryVoronoiContainer, VictoryTooltip, VictoryLegend } from 'victory';
import { useDispatch, useSelector } from "react-redux";
import { getCostCurveData } from "../../../../../redux/actions/ImpackTrackingAction";

const CostCurve = ({ aspect, title, height, width, responsive = false }) => {
  const dispatch = useDispatch();
  const data = useSelector((state) => state.impactReducer.victCostCurve);
  const stage1Data = useSelector((state) => state.impactReducer.stage1RowDataSelected);
  const { analysis_job_id = '' } = stage1Data;

  useEffect(() => {
    dispatch(getCostCurveData(analysis_job_id));
}, [dispatch, analysis_job_id]);

  
  let group = [];
  const control = [];
   if(data.Control)
   group.push(...data.Control);
   if(data.Study)
   control.push(...data.Study);
   const axisRangeX = data.AxisDomainRanges ? data.AxisDomainRanges.domainX : '';
   const axisRangeY = data.AxisDomainRanges ? data.AxisDomainRanges.domainY : '';
   
  const viewBoxVar = "0 0 " + width +" "+ height;

  const legendInfo = data.LegendInfo;
  let dataSlopeLabelArr = [];
  let a, b, c, d, e, slope, yIntercent, objStartPoint, objEndPoint;
  let infoAngle = [];

  const treadline = (data) => {
      let xSum = 0, ySum = 0, xySum = 0, xSquare = 0, dpsLength = data.length;
      for(var i = 0; i <  dpsLength; ++i){
        xSum += data[i].x;
        ySum += data[i].y;
        xySum += data[i].x * data[i].y;
        xSquare += Math.pow(data[i].x, 2);
      }
      a = xySum * dpsLength;
      b = xSum * ySum;
      c = dpsLength * xSquare;
      d = Math.pow(xSum, 2);

      slope = (a-b) / (c-d);
      console.log("slopse :" + slope);
      e = slope * xSum;

      yIntercent = (ySum - e) / dpsLength;
      // x is the startting of the x on the graph which default 0
      objStartPoint = getTreadPoints(data[0].x, slope, yIntercent);
      objEndPoint = getTreadPoints(data[data.length-1].x, slope, yIntercent);
      slopeLabel(slope, yIntercent);
      return [objStartPoint, objEndPoint];
      
  }; 

  const getTreadPoints = (x, slope, yIntercent) => {
        
        let store = {x : x , y: (((slope * x) + yIntercent))}
        if(infoAngle.length === 2){
          infoAngle = [];
        }
        infoAngle.push(store);
        return store;
  }

  const roundUp4Dec = (num) => {
       return (Math.round(num * 10) / 10) 
  }

  const slopeLabel =(slope, yIntercent) =>{
    dataSlopeLabelArr.push( "y= " + roundUp4Dec(slope) +"x + " + roundUp4Dec(yIntercent));

  }


  const labelMonthCount = () => {
    let labelArr = [];
    if (control.length > group.length) {
      for (let i = 0; i < control.length; ++i) {
        labelArr.push(control[i].x);
      }
    } else {
      for (let i = 0; i < group.length; ++i) {
        labelArr.push(group[i].x);
      }
    }
    return labelArr;
  }

  return (
    <div >
      <VictoryChart

        height={height}
        width={width}
        containerComponent={<VictoryVoronoiContainer responsive={responsive} />}
      >

        <VictoryAxis orientation='bottom' label={"Month"} domain={axisRangeX} tickValues={labelMonthCount()} style={{ tickLabels: { fontSize: 8, padding: 5, fontFamily: "Arial" }, axisLabel: { fontSize: 8, padding: 18, fontFamily: "Arial" } }} />
        <VictoryAxis dependentAxis offsetX={50} label={"Impactable Total PMPM"} orientation="left" domain={axisRangeY} style={{ tickLabels: { fontSize: 8, padding: 3, fontFamily: "Arial" }, axisLabel: { fontSize: 8, padding: 30, fontFamily: "Arial" } }} />
        <VictoryAxis dependentAxis crossAxis style={{ grid: { stroke: ({ tick }) => tick === 0 ? "#1a3673" : "white" }, axis: { strokeDasharray: "6,2" }, tickLabels: { fontSize: 0 } }} />
        <VictoryLine

          labels={({ datum }) => ` ${datum.x === 0 ? "" + datum.y : datum.y}`}
          labelComponent={
            <VictoryTooltip
              style={{ fontSize: 10 }}
            />
          }
          data={group} style={{ data: { stroke: "#896897" } }} />
        <VictoryLine
          labels={({ datum }) => `${datum.x === 0 ? "" + datum.y : datum.y}`}
          labelComponent={
            <VictoryTooltip
              style={{ fontSize: 10 }}
            />
          }

          data={control} style={{ data: { stroke: "#f48b49" } }} />


        <VictoryLegend x={width - (width / 1.5)} y={0}
          title="Cost Curve Pre- and Post-Event"
          titleOrientation="top"
          gutter={20}
          orientation="horizontal"

          style={{ title: { fontSize: 12, fontFamily: "Arial" }, labels: { fontSize: 8, fontFamily: "Arial" } }}
          data={[
            { name: "Study Group", symbol: { fill: "#f48b49" } }, { name: "Control Group", symbol: { fill: "#896897" } }, { name: "Event Month Zero", symbol: { fill: "black" } }
          ]}
        />
      </VictoryChart>
    </div>
  );
};


export default CostCurve;
