import React from "react";
import { useSelector } from "react-redux";
import styled from "styled-components";
import { VictoryAxis, VictoryChart, VictoryLine, VictoryScatter, VictoryLabel, VictoryVoronoiContainer, VictoryGroup, VictoryTooltip, VictoryLegend, VictoryBar, VictoryTheme } from 'victory';

function BarGraph(props) {


 let contractedData = props.data;

 

 const rebuildData = (data) => {
       let rebuiltData = [];
       data.map((data, i) => {
          let holder = {};
          holder["modifiedDid"] = data.did;
          holder["display_name"] = data.display_name;
          if(data.did < 0){
             holder["negValue"] = true;
             holder.modifiedDid = -1 * data.did;
          } else {
            holder["negValue"] = false; 
          }
          holder["program_impact"] = data.program_impact;
          holder["did"] =holder.modifiedDid;
          
          rebuiltData.push(holder);
       });
       return rebuiltData.reverse();
 }

 function formatAsPercent(num) {
  let temp = new Intl.NumberFormat('default', {
    style: 'percent',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(num);
  return temp;
}

const StyledLabel = styled(VictoryLabel)`
  tspan {

    fill: magenta;
    font-family: Roboto,Helvetica,Arial,sans-serif !important;
  }`
 

    return (<div>

<VictoryChart
domainPadding={{ y: [50, 130] }}

>
<VictoryAxis dependentAxis offsetX={0} orientation='bottom'  style={{axis: {display:"none"}, tickLabels: {display:"none"}}}/>
<VictoryAxis offsetX={120} offsetY={30} orientation="right" style={{axis: {stroke : "transparent"}, tickLabels: {fontSize: 0, padding: 1, fontFamily:"Arial", textAnchor:"begin"}}} />

  <VictoryBar horizontal

    barWidth={5}
    style={{ data: { fill: ({datum}) => {
      return datum.negValue ? "#00bbba" : "#d04348"} }, labels: {fontSize:6} }}
    data={rebuildData(contractedData)}
    orientation="begin"
    y="did"
    x="display_name"
    labels={({ datum }) => [ (datum.negValue) ? "$-"+datum.did : "$"+datum.did, (`(${formatAsPercent(datum.program_impact)})`), datum.display_name]}
    labelComponent={
      <StyledLabel
      dx={3}
      inline
      backgroundStyle={
        [{ fill: "white" },
        { fill: "white" },
        { fill: "white" },
      ]
      }
      textAnchor={"start"}
      verticalAnchor={"middle"}
      
      />
    }
    
    alignment="begin"
  />
</VictoryChart>

    </div>
    );
}

  export default BarGraph; 