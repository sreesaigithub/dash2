import React from 'react';
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';
import { useDispatch, useSelector } from 'react-redux';
import { failureErrorInfo } from '../../../../../redux/actions/ImpackTrackingAction';

const Alert = React.forwardRef(function Alert(props, ref) {
    return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

export default function AlertErrorView() {
    const [open, setOpen] = React.useState(false);
    const error = useSelector((state) => state.impactReducer.error);
    const dispatch = useDispatch();
    const vertical = 'top', horizontal = 'right';

    React.useEffect(() => {
        return () => {
            handleClose();
          };
    }, []);
    
    React.useEffect(() => {
        setOpen(error !== '');
    }, [error]);


    const handleClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }

        setOpen(false);
        dispatch(failureErrorInfo(''));
    };

    return (
        <Snackbar
            anchorOrigin={{ vertical, horizontal }}
            key={vertical + horizontal}
            open={open}
            autoHideDuration={5000}
            onClose={handleClose}>
            <Alert
                onClose={handleClose}
                severity="error"
                sx={{ width: '100%' }}>
                {error}
            </Alert>
        </Snackbar>
    );
}
