import React from "react";
import reporting from "../../../Images/AnalyticsReporting_icon.svg";
import { useSelector } from "react-redux";

function ExecutiveBoard() {
  const tierName = useSelector((state) => state.authReducer.tierName);
  const tierLevel = useSelector((state) => state.authReducer.tierLevel);

  return (
    <>
      <div
        className={`icon-wrapper ${
          tierName === "Executive" && tierLevel === 2 ? "d-flex" : "d-none"
        }`}
      >
        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Executive%20Dashboards/Executive%20Dashboard%20Commercial?rs:embed=true"
            target="_blank"
          >
            <img src={reporting} alt="Analytics and Reporting Icon" />
            <span>Commercial</span>
          </a>
        </div>

        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Executive%20Dashboards/Executive%20Dashboard%20Medicaid?rs:embed=true"
            target="_blank"
          >
            <img src={reporting} alt="Analytics and Reporting Icon" />
            <span>Medicaid</span>
          </a>
        </div>

        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Executive%20Dashboards/Executive%20Dashboard%20Medicare?rs:embed=true"
            target="_blank"
          >
            <img src={reporting} alt="Analytics and Reporting Icon" />
            <span>Medicare</span>
          </a>
        </div>

        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/browse/Executive%20Dashboards/Executive%20Dashboard%20Pivot%20Table%20Consolidated%20Workbooks"
            target="_blank"
          >
            <img src={reporting} alt="Analytics and Reporting Icon" />
            <span>Excel</span>
          </a>
        </div>
      </div>
    </>
  );
}

export default ExecutiveBoard;
