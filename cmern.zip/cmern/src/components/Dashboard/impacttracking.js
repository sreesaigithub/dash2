import React from "react";

function impacttracking() {
  return <div>Impack Tracking under development</div>;
}

export default impacttracking;
