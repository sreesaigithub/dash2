import * as React from 'react';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import ListItemText from '@mui/material/ListItemText';
import Select from '@mui/material/Select';
import Checkbox from '@mui/material/Checkbox';
import { Tooltip } from '@mui/material';
import ClearIcon from "@mui/icons-material/Clear";
import IconButton from "@mui/material/IconButton";

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 0;
const MenuProps = {
    PaperProps: {
        style: {
            maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
            width: 260,
            marginLeft: 10,
        },
    },
};
const commercialDefault = 'Commercial';
let defaultCommercialMBUclass = 'Commercial';
export default function Lob({ dataArray, setLOB, setMBUclass, setSA, setProduct, lob, mbuclass }) {

    const [checked, setChecked] = React.useState([commercialDefault]);
    const [selectedArray, setSelectedArray] = React.useState([commercialDefault]);
    // let [defaultCommercialMBUclass, setdefaultCommercialMBUclass] = React.useState([]);
    let [selectedArrayValue, setSelectedArrayValue] = React.useState([defaultCommercialMBUclass]);
    const [selectedParentName, setSelectedParentName] = React.useState(commercialDefault);

    const handleToggle =
        (values, label, id, children, selectedParentObj, selectedObj, mbuclass) => () => {
            if (
                selectedArray.length === 0 ||
                selectedParentObj.label === selectedParentName
            ) {
                const currentIndex = mbuclass.indexOf(values);
                let newChecked = [...checked];
                let newselectedArray = [...selectedArray];
                let value = [...selectedArrayValue]
                if (currentIndex === -1) {
                    newselectedArray.push(id);
                    const selectedParentValue = selectedParentObj.label
                        ? selectedParentObj.label
                        : '';
                    newChecked.push(label)
                    value.push(selectedObj.value)
                    setSelectedParentName(selectedParentValue);
                } else {
                    newChecked.splice(currentIndex, 1);
                    newselectedArray = newselectedArray.filter(x => x !== id)
                    value = value.filter(x => x !== selectedObj.value)
                    if (newChecked.length === 0) {
                        newChecked = [...[commercialDefault]];
                        setSelectedParentName(commercialDefault);
                        newselectedArray = [...[defaultCommercialMBUclass]];
                        value = [...[defaultCommercialMBUclass]];
                    }
                }
                setChecked(newChecked);
                setSelectedArray(newselectedArray);
                setSelectedArrayValue(value)
            } else {
                let checked = [selectedObj.label];
                let value = [selectedObj.value]
                setSelectedArrayValue(value)
                setSelectedParentName(selectedParentObj.label);
                setSelectedArray([id]);
                setChecked(checked);
            }
        };
    React.useEffect(() => {
        if (!selectedParentName) {
            setSA(['All']);
            setProduct(['All']);
            setLOB(commercialDefault);
        } else {
            setSA(['All']);
            setProduct(['All']);
            setLOB(selectedParentName);
        }
    }, [selectedParentName]);
    React.useEffect(() => {
        if (selectedArrayValue.length === 0) {
            setSA(['All']);
            setProduct(['All']);
            setMBUclass(defaultCommercialMBUclass);
        } else {
            setSA(['All']);
            setProduct(['All']);
            setMBUclass(selectedArrayValue);
        }
    }, [selectedArrayValue]);

    const handleClearClick = () => {
        setSA(['All']);
        setProduct(['All']);
        setLOB(commercialDefault);
        setSelectedArrayValue([defaultCommercialMBUclass]);
        setChecked([commercialDefault]);
        setSelectedArray([commercialDefault]);
        setSelectedParentName(commercialDefault);
        setMBUclass([defaultCommercialMBUclass]);
    };
    return (
        <div>
            <FormControl variant="standard" className="formControlWidth" sx={{ m: 1 }} size="small">
                <InputLabel id="lob-label" className="formControlWidthLabel"><span className="fontDisplay">LOB</span></InputLabel>
                <Select
                    labelId="lob-label"
                    id="lob"
                    multiple
                    value={dataArray}
                    defaultValue="Commercial"
                    style={{ fontSize: '12px' }}
                    sx={{ "& .MuiSelect-iconStandard": { right: "20px" }, "& .MuiMenu-paper": { left: "165px" } }}
                    renderValue={() => checked.join(', ')}
                    endAdornment={<IconButton sx={{ padding: '0px' }} onClick={() => handleClearClick()}>
                        <Tooltip title={"Clear filter"}>
                            <ClearIcon sx={{ height: '.7em', width: '.7em' }} />
                        </Tooltip>
                    </IconButton>}
                    MenuProps={MenuProps}
                >
                    {dataArray.map((value, id) => {
                        return (
                            <ToggleList
                                key={id}
                                item={value}
                                id={id}
                                parentObj={value}
                                handleToggle={handleToggle}
                                checked={checked}
                                mbuclass={mbuclass}
                            />
                        );
                    })}
                </Select>
            </FormControl>
        </div>
    );
}
function ToggleList({ id, item, handleToggle, parentObj, checked, mbuclass }) {
    const [show, setShow] = React.useState(false);
    const handleShow = () => {
        setShow((show) => !show);
    };
    return (
        <div
            style={{
                display: 'inline',
            }}
        >
            {' '}
            {item.children.length ? (
                <span
                    style={{
                        position: 'relative',
                        cursor: 'pointer',
                        float: 'left',
                        left: '14px',
                        top: '5px',
                        zIndex: '1',
                    }}
                    onClick={handleShow}
                >
                    {show ? '-' : '+'}
                </span>
            ) : null}
            {/* <Tooltip title={item.label} key={item.label}> */}
            <MenuItem
                key={id}
                value={item.label}
                onClick={handleToggle(
                    item.value,
                    item.label,
                    id,
                    item.children,
                    parentObj,
                    item,
                    mbuclass
                )}
            >
                <Checkbox size="small" style={{ padding: '0 9px' }} checked={mbuclass.indexOf(item.value) > -1} />
                <ListItemText primaryTypographyProps={{ fontSize: '14px' }} primary={item.label} />
            </MenuItem>
            {/* </Tooltip> */}
            <div
                style={{
                    marginLeft: '28px',
                }}
            >
                {show &&
                    item.children.length &&
                    item.children.map((values, ids) => (
                        <ToggleList
                            key={ids}
                            item={values}
                            id={ids}
                            parentObj={parentObj}
                            handleToggle={handleToggle}
                            checked={checked}
                            mbuclass={mbuclass}
                        />
                    ))}
            </div>
        </div>
    );
}
