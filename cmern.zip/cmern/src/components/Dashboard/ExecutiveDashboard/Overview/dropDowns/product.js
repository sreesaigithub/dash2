import * as React from 'react';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import ListItemText from '@mui/material/ListItemText';
import Select from '@mui/material/Select';
import Checkbox from '@mui/material/Checkbox';
import ClearIcon from "@mui/icons-material/Clear";
import IconButton from "@mui/material/IconButton";
import { Tooltip } from '@mui/material';

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
    PaperProps: {
        style: {
            maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
            width: 250,
            marginLeft: 10,
        },
    },
};
const defaultValue = 'All';
const traverse = (arr, output) => {
    for (let item of arr) {
        output.push(item.label);
        if (item.children) {
            output = traverse(item.children, output);
        }
    }
    return output
}
export default function Product({ dataArray, setProduct, lob, mbuClass, sa, product }) {
    const [checked, setChecked] = React.useState([defaultValue]);
    const [selectedArrayValue, setSelectedArrayValue] = React.useState([]);
    const [all, setAll] = React.useState([]);

    const handleToggle =
        (values, label, id, children, selectedParentObj, selectedObj, product) => () => {
            const currentIndex = product.indexOf(values);
            //  const currentIndex = checked.indexOf(label);
            let newChecked = [...checked];
            let value = [...selectedArrayValue];
            if (label !== 'All') {
                newChecked = newChecked.filter(x => x !== 'All')
            } else {
                newChecked = [];
            }
            if (currentIndex === -1) {
                if (label === 'All') {
                    newChecked.push(label);
                    value = [];
                } else {
                    newChecked.push(label);
                    value.push(selectedObj.value);
                }
            } else {
                newChecked.splice(currentIndex, 1);
                value = value.filter(x => x !== selectedObj.value);
                if (newChecked.length === 0) {
                    newChecked = ['All'];
                    setProduct([]);
                }
            }
            setChecked(newChecked);
            setSelectedArrayValue(value);
        };
    React.useEffect(() => {
        let values = traverse(dataArray, []);
        setAll(values);
    }, [dataArray])

    React.useEffect(() => {
        setProduct([defaultValue]);
        setChecked([defaultValue]);
        setSelectedArrayValue([]);
}, [lob, sa , mbuClass ]);

    React.useEffect(() => {
        if (selectedArrayValue.length === 0) {
            setProduct([defaultValue]);
        } else {
            setProduct(selectedArrayValue);
        }
    }, [selectedArrayValue]);
    
    const handleClearClick = () => {
        setProduct([defaultValue]);
        setChecked([defaultValue]);
        setSelectedArrayValue([]);
    };
    return (
        <div>
            <FormControl variant="standard" className="formControlWidth" sx={{ m: 1 }} size="small">
                <InputLabel id="product-label" className="formControlWidthLabel"><span className="fontDisplay">Product</span></InputLabel>
                <Select
                    labelId="product-label"
                    id="product-state"
                    multiple
                    value={dataArray}
                    style={{ fontSize: '12px' }}
                    sx={{ "& .MuiSelect-iconStandard": { right: "20px" }, "& .MuiMenu-paper": { left: "165px" } }}
                    renderValue={() => checked.join(', ')}
                    endAdornment={<IconButton sx={{ padding: '0px' }} onClick={() => handleClearClick()}>
                        <Tooltip title={"Clear filter"}>
                            <ClearIcon sx={{ height: '.7em', width: '.7em' }} />
                        </Tooltip>
                    </IconButton>}
                    MenuProps={MenuProps}
                >
                    {dataArray.map((value, id) => {
                        return (
                            <ToggleList
                                key={id}
                                item={value}
                                id={id}
                                parentObj={value}
                                handleToggle={handleToggle}
                                checked={checked}
                                product={product}
                            />
                        );
                    })}
                </Select>
            </FormControl>
        </div>
    );
}
function ToggleList({ id, item, handleToggle, parentObj, checked, product }) {
    const [show, setShow] = React.useState(false);
    const handleShow = () => {
        setShow((show) => !show);
    };
    return (
        <div
            style={{
                display: 'inline',
            }}
        >
            {' '}
            {item.children.length ? (
                <span
                    style={{
                        position: 'relative',
                        cursor: 'pointer',
                        float: 'left',
                        left: '14px',
                        top: '5px',
                        zIndex: '1',
                    }}
                    onClick={handleShow}
                >
                    {show ? '-' : '+'}
                </span>
            ) : null}
            <MenuItem
                key={id}
                value={item.label}
                onClick={handleToggle(
                    item.value,
                    item.label,
                    id,
                    item.children,
                    parentObj,
                    item,
                    product
                )}
            >
                <Checkbox size="small" style={{ padding: '0 9px' }} checked={product.indexOf(item.value) > -1} />

                <ListItemText primaryTypographyProps={{ fontSize: '14px' }} primary={item.label} />
            </MenuItem>
            <div
                style={{
                    marginLeft: '28px',
                }}
            >
                {show &&
                    item.children.length &&
                    item.children.map((values, ids) => (
                        <ToggleList
                            key={ids}
                            item={values}
                            id={ids}
                            parentObj={parentObj}
                            handleToggle={handleToggle}
                            checked={checked}
                            product={product}
                        />
                    ))}
            </div>
        </div>
    );
}
