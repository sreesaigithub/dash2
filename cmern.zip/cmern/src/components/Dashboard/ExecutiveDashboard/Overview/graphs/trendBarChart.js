import React from "react";
import { Bar, Chart } from "react-chartjs-2";
import ChartDataLabels from 'chartjs-plugin-datalabels';
import moment from 'moment';


const TrendBarChart = ({ data, prop, sign, arrow }) => {
 
  const barChartData = {
    labels: data ? data.xvalue : [0],
    
  datasets: [
    {label: "Prior",
        data: data ?  data.y2Value : [0],
        borderColor: "#3333ff",
        fill: true,
        backgroundColor: "#6A97DF",
        barThickness: 7,
        maxBarLength: 1,
        datalabels: {
            display: false,
            align: 'right',
            anchor: 'center',
            color: 'black',
            rotation: 0,
            font: {
              weight: ''
            }
          }
      },
    {
        label: null,
        backgroundColor: "white",
        barThickness: 2,
        data: null,
      },
      {
        label: "Current",
      data: data ? data.y1Value : [0],
      borderColor: "#3333ff",
      fill: true,
      backgroundColor: "#1A3673",
      barThickness: 7,
      maxBarLength: 1,
      datalabels: {
        display: false,
        align: 'left',
        anchor: 'center',
        color: 'black',
        rotation: 0,
        font: {
          weight: ''
        }
      }
    },
    
  ],
};

const option = {
  layout: {
    padding: {
        left: 0,
        right: 10,
        top: 5,
        bottom: 0
    }
},
  plugins: {
    legend: {
      display: false,
    },
    tooltip: {
        callbacks: {
        title: function () {       
          return '';
      },
      label: function(context) {
        let label = context.dataset.label || '';

        if (label) {
            label += ': ';
        }
        if (context.parsed.y !== null) {
            label += new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD',  minimumFractionDigits: 0,
            maximumFractionDigits: 0 }).format(context.parsed.y);
        }
        return label;
    },
        }
    },
    datalabels: {
      labels: {
        display: false,
        index: {
          align: "top",
          anchor: "center",
          color: "black",
          font: {
            size: 14,
            weight: "",
          },
          padding:{
            bottom:-5,              
          },
          formatter: function (value, context) {
            if(!value)
            {return value;}
            else{
                value = value.toString();
                value = value.split(/(?=(?:...)*$)/);
                value = value.join(',');
                return value;
              
            }            
          },
        },
      },
    },
  },
  categoryPercentage: 0, 
  barPercentage: 0.98,  
  scales: {
    x: {
      ticks: {
        callback: function (value) {
            let valueLegend = this.getLabelForValue(value);
            var date = moment(valueLegend, "MM").format('MMM');
            return date;
        },
    },
      grid: {
        display: false,
      },
    },
    y: {
        ticks: {
            // Include a dollar sign in the ticks
            callback: function (value, index, ticks) {
                const valueLegend = this.getLabelForValue(value);
                var valueLegendRep = valueLegend.replaceAll(',', '');
                if (valueLegendRep.length <= 3) {
                    return '$' + valueLegendRep;
                }
                if (valueLegendRep.length === 4) {
                    return '$' + valueLegendRep.substr(0, 1) + 'k';
                }
                if (valueLegendRep.length === 5) {
                    return '$' + valueLegendRep.substr(0, 2) + 'k';
                }
                if (valueLegendRep.length === 6) {
                    return '$' + valueLegendRep.substr(0, 3) + 'k';
                }
                if (valueLegendRep.length === 7) {
                    return '$' + valueLegendRep.substr(0, 4) + 'k';
                }
            }
        },
      title: {
        display: true,
        text: 'Expense PMPM',
        font: {
            weight: "bold",
            size:"9px"
        },
    },
     
      grid: {
        display: false,
      },
    },
  },
};

  const trendBar = (
    <Bar
      data={barChartData} height="50px" options={option} padding="0px" 
    />
  );
  return trendBar;
};

export default TrendBarChart;