import React from 'react';
import SquareSharpIcon from '@mui/icons-material/SquareSharp';

export default function PriorLabel () {
    return (
<div>
<div style={{ display: 'flex' }}>
<SquareSharpIcon style={{ color: "#6A97DF" }} /> <span >Prior</span>
        &nbsp;&nbsp; &nbsp;&nbsp;
        <SquareSharpIcon style={{ color: "#1A3673" }} /> <span >Current</span>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <div>
          <span style={{ fontWeight: 'bold' }} >Note:&nbsp;</span>
          <span >Ranking vs. All Markets</span>
      </div>
</div>
   </div>    

    );
}