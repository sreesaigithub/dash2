import React from "react";
import { useSelector } from "react-redux";
import commercial from "../../../Images/COC-Commercial.png";
import Medicaid from "../../../Images/COC-Medicaid.png";
import Medicare from "../../../Images/COC-Medicare.png";
import COCFGS from "../../../Images/COC-FGS.png";
import Excel from "../../../Images/COC-Excel.png";

function COCClinicalCondition() {
  const tierName = useSelector((state) => state.authReducer.tierName);
  const tierLevel = useSelector((state) => state.authReducer.tierLevel);
  return (
    <>
      <div
        className={`icon-wrapper cocclinicalCareWrapper ${
          tierName === "COC_Clinical" && tierLevel === 3 ? "d-flex" : "d-none"
        }`}
      >
        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Clinical%20Conditions/COC%20Commercial%20Clinical%20Conditions?rs:embed=true"
            target="_blank"
          >
            <img src={commercial} alt="COC Clinical Commercial Icon" />
            <span>Commercial</span>
          </a>
        </div>

        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Clinical%20Conditions/COC%20Medicaid%20Clinical%20Conditions?rs:embed=true"
            target="_blank"
          >
            <img src={Medicaid} alt="COC Clinical Medicaid Icon" />
            <span>Medicaid</span>
          </a>
        </div>

        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Clinical%20Conditions/COC%20Medicare%20Clinical%20Conditions?rs:embed=true"
            target="_blank"
          >
            <img src={Medicare} alt="COC Clinical Medicare Icon" />
            <span>Medicare</span>
          </a>
        </div>

        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Clinical%20Conditions/COC%20FGS%20Clinical%20Conditions?rs:embed=true"
            target="_blank"
          >
            <img src={COCFGS} alt="COC Clinical FGS Icon" />
            <span>FGS</span>
          </a>
        </div>

        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/browse/Clinical%20Conditions/Clinical%20Condition%20Excel%20Pivots"
            target="_blank"
          >
            <img src={Excel} alt="COC Clinical Excel Icon" />
            <span>Excel Pivot</span>
          </a>
        </div>
      </div>
    </>
  );
}

export default COCClinicalCondition;
