import React, { useState } from "react";

import COCVisualIcon from "../../../Images/COC-Visual.png";

import COCMatrixIcon from "../../../Images/COC-Matrix.png";
import COCCovidIcon from "../../../Images/COC-Covid.png";
import COCClinicIcon from "../../../Images/COC-Clinic.png";
import COCOncologyIcon from "../../../Images/COC-Oncology.png";

import CoCVisualCare from "./CoCVisualCare";
import COCMatrix from "./COCMatrix";
import COCClinicalCondition from "./COCClinicalCondition";
import COCCovid from "./COCCovid";
import COCOncology from "./COCOncology";
import { useDispatch, useSelector } from "react-redux";
import { updatetierInfo } from "../../../redux/actions/authAction";

function CoCDashboard() {
  const [showCocWrap, setShowCocWrap] = useState(true);
  const [showVisual, setShowVisual] = useState(false);

  const dispatch = useDispatch();
  const tierName = useSelector((state) => state.authReducer.tierName);
  const tierLevel = useSelector((state) => state.authReducer.tierLevel);
  return (
    <>
      <div
        className={`icon-wrapper costOfCare-wrapper ${
          (tierName === "COC" ||
            tierName === "COC_VisualCare" ||
            tierName === "COC_Matrix" ||
            tierName === "COC_Clinical" ||
            tierName === "COC_Covid" ||
            tierName === "COC_Oncology") &&
          tierLevel === 2
            ? "d-flex"
            : "d-none"
        }`}
      >
        <div className="icon">
          <a
            onClick={() => {
              dispatch(
                updatetierInfo({ tierLevel: 3, tierName: "COC_VisualCare" })
              );
            }}
          >
            <img src={COCVisualIcon} alt="COC Visual Icon" />
            <span>
              Cost of Care
              <br />
              Visual
            </span>
          </a>
        </div>

        <div className="icon">
          <a
            onClick={() => {
              dispatch(
                updatetierInfo({ tierLevel: 3, tierName: "COC_Matrix" })
              );
            }}
          >
            <img src={COCMatrixIcon} alt="COC Matrix Icon" />
            <span>
              Cost of Care
              <br />
              Matrix
            </span>
          </a>
        </div>

        <div className="icon">
          <a
            onClick={() => {
              dispatch(updatetierInfo({ tierLevel: 3, tierName: "COC_Covid" }));
            }}
          >
            <img src={COCCovidIcon} alt="COC Covid Icon" />
            <span>
              Covid 19
              <br />
              &nbsp;
            </span>
          </a>
        </div>

        <div className="icon">
          <a
            onClick={() => {
              dispatch(
                updatetierInfo({ tierLevel: 3, tierName: "COC_Clinical" })
              );
            }}
          >
            <img src={COCClinicIcon} alt="COC Clinical Icon" />
            <span>
              Clinical
              <br />
              Condition
            </span>
          </a>
        </div>

        <div className="icon">
          <a
            onClick={() => {
              dispatch(
                updatetierInfo({ tierLevel: 3, tierName: "COC_Oncology" })
              );
            }}
          >
            <img src={COCOncologyIcon} alt="COC Oncology Icon" />
            <span>
              Oncology
              <br />
              &nbsp;
            </span>
          </a>
        </div>
      </div>
      {tierLevel === 3 && tierName === "COC_VisualCare" && <CoCVisualCare />}
      {tierLevel === 3 && tierName === "COC_Matrix" && <COCMatrix />}
      {tierLevel === 3 && tierName === "COC_Covid" && <COCCovid />}
      {tierLevel === 3 && tierName === "COC_Clinical" && (
        <COCClinicalCondition />
      )}
      {tierLevel === 3 && tierName === "COC_Oncology" && <COCOncology />}
    </>
  );
}

export default CoCDashboard;
