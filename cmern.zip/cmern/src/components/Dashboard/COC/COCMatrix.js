import React from "react";
import { useSelector } from "react-redux";
import commercial from "../../../Images/COC-Commercial.png";
import Medicaid from "../../../Images/COC-Medicaid.png";
import Medicare from "../../../Images/COC-Medicare.png";
import COCFGS from "../../../Images/COC-FGS.png";

function COCMatrix() {
  const tierName = useSelector((state) => state.authReducer.tierName);
  const tierLevel = useSelector((state) => state.authReducer.tierLevel);
  return (
    <>
      <div
        className={`icon-wrapper cocmatrixCareWrapper ${
          tierName === "COC_Matrix" && tierLevel === 3 ? "d-flex" : "d-none"
        }`}
      >
        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Cost%20of%20Care%20Matrix%20Reports/Cost%20of%20Care%20Matrix%20Commercial?rs:embed=true"
            target="_blank"
          >
            <img src={commercial} alt="COC Matrix Commercial Icon" />
            <span>Commercial</span>
          </a>
        </div>

        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Cost%20of%20Care%20Matrix%20Reports/Cost%20of%20Care%20Matrix%20Medicaid?rs:embed=true"
            target="_blank"
          >
            <img src={Medicaid} alt="COC Matrix Medicaid Icon" />
            <span>Medicaid</span>
          </a>
        </div>

        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Cost%20of%20Care%20Matrix%20Reports/Cost%20of%20Care%20Matrix%20Medicare?rs:embed=true"
            target="_blank"
          >
            <img src={Medicare} alt="COC Matrix Medicare Icon" />
            <span>Medicare</span>
          </a>
        </div>

        <div className="icon">
          <a
            href="https://va10pwpsas404.us.ad.wellpoint.com/Reports/powerbi/Cost%20of%20Care%20Matrix%20Reports/Cost%20of%20Care%20Matrix%20FGS?rs:embed=true"
            target="_blank"
          >
            <img src={COCFGS} alt="COC Matrix FGS Icon" />
            <span>FGS</span>
          </a>
        </div>
      </div>
    </>
  );
}

export default COCMatrix;
